import adsk.core
import traceback

from ..lib import constants as C
from ..lib import fusion_utils as F
from ..lib import sketch_debug_service as S

_app = adsk.core.Application.get()
_ui = _app.userInterface if _app else None
_handlers = []

INP_FACES = 'numberFaces'
INP_START = 'numberStart'
INP_SIZE = 'numberSize'
INP_SUMMARY = 'numberSummary'


def _selected_faces(inputs):
    return S.resolve_selected_planar_faces(inputs.itemById(INP_FACES))


def _update_summary(inputs):
    faces = _selected_faces(inputs)
    inputs.itemById(INP_SUMMARY).text = S.number_summary(faces, int(round(inputs.itemById(INP_START).value)))


class Created(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = adsk.core.Command.cast(args.command)
            inputs = cmd.commandInputs

            face_inp = inputs.addSelectionInput(INP_FACES, 'Planar faces', 'Select one or more planar faces for numbered sketches')
            face_inp.addSelectionFilter('PlanarFaces')
            face_inp.setSelectionLimits(1, 0)

            inputs.addIntegerSpinnerCommandInput(INP_START, 'Starting number', 1, 9999, 1, 1)
            inputs.addValueInput(INP_SIZE, 'Digit size', 'mm', F.value_input_mm(C.DEFAULTS['number_size_mm']))
            inputs.addTextBoxCommandInput(INP_SUMMARY, 'Summary', 'Select one or more planar faces.', 6, True)

            _update_summary(inputs)

            for handler_cls, event in [
                (InputChanged, cmd.inputChanged),
                (Validate, cmd.validateInputs),
                (Execute, cmd.execute),
                (Destroy, cmd.destroy),
            ]:
                handler = handler_cls()
                event.add(handler)
                _handlers.append(handler)
        except:
            if _ui:
                _ui.messageBox('Number Sketch command creation failed:\n{}'.format(traceback.format_exc()))


class InputChanged(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.InputChangedEventArgs.cast(args).inputs
            _update_summary(inputs)
        except:
            F.log(traceback.format_exc())


class Validate(adsk.core.ValidateInputsEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.ValidateInputsEventArgs.cast(args).inputs
            faces = _selected_faces(inputs)
            args.areInputsValid = bool(faces)
        except:
            F.log(traceback.format_exc())


class Execute(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.CommandEventArgs.cast(args).command.commandInputs
            faces = _selected_faces(inputs)
            if not faces:
                raise RuntimeError('Select one or more planar faces.')

            start_number = int(round(inputs.itemById(INP_START).value))
            size_mm = F.cm_to_mm(inputs.itemById(INP_SIZE).value)
            sketches = S.create_number_sketches(
                faces=faces,
                starting_number=start_number,
                size_mm=size_mm,
            )
            end_number = start_number + len(sketches) - 1
            _ui.messageBox('Created {} numbered sketch(es), from {} to {}.'.format(len(sketches), start_number, end_number))
        except:
            if _ui:
                _ui.messageBox('Number Sketch failed:\n{}'.format(traceback.format_exc()))


class Destroy(adsk.core.CommandEventHandler):
    def notify(self, args):
        pass


def start():
    cmd_def = _ui.commandDefinitions.itemById(C.CMD_NUMBER_SKETCH_ID)
    if not cmd_def:
        cmd_def = _ui.commandDefinitions.addButtonDefinition(
            C.CMD_NUMBER_SKETCH_ID,
            C.CMD_NUMBER_SKETCH_NAME,
            C.CMD_NUMBER_SKETCH_DESCRIPTION,
        )
    created = Created()
    cmd_def.commandCreated.add(created)
    _handlers.append(created)

    panel = _ui.workspaces.itemById(C.WORKSPACE_ID).toolbarPanels.itemById(C.PANEL_ID)
    if not panel.controls.itemById(C.CMD_NUMBER_SKETCH_ID):
        panel.controls.addCommand(cmd_def)


def stop():
    panel = _ui.workspaces.itemById(C.WORKSPACE_ID).toolbarPanels.itemById(C.PANEL_ID)
    control = panel.controls.itemById(C.CMD_NUMBER_SKETCH_ID)
    if control:
        control.deleteMe()
    cmd_def = _ui.commandDefinitions.itemById(C.CMD_NUMBER_SKETCH_ID)
    if cmd_def:
        cmd_def.deleteMe()
