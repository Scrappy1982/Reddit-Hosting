import adsk.core
import adsk.fusion
import traceback

from ..lib import constants as C
from ..lib import fusion_utils as F
from ..lib import sketch_debug_service as S

_app = adsk.core.Application.get()
_ui = _app.userInterface if _app else None
_handlers = []

INP_FACES = 'connectorFaces'
INP_PLACEMENT = 'connectorPlacement'
INP_POINTS = 'connectorPoints'
INP_TYPE = 'connectorType'
INP_COUNT = 'connectorCount'
INP_MARGIN = 'connectorMargin'
INP_PIN_D = 'connectorPinDiameter'
INP_PIN_DEPTH = 'connectorPinDepth'
INP_CREATE_DOWELS = 'connectorCreateDowels'
INP_RECT_W = 'connectorRectWidth'
INP_RECT_H = 'connectorRectHeight'
INP_SUMMARY = 'connectorSummary'


def _selected_faces(inputs):
    return S.resolve_selected_planar_faces(inputs.itemById(INP_FACES))


def _dropdown_name(inputs, inp_id):
    return F.get_dropdown_name(inputs.itemById(inp_id))


def _mm_value(inputs, inp_id):
    return F.cm_to_mm(inputs.itemById(inp_id).value)


def _update_visibility(inputs):
    placement_mode = _dropdown_name(inputs, INP_PLACEMENT)
    connector_type = _dropdown_name(inputs, INP_TYPE)

    inputs.itemById(INP_POINTS).isVisible = placement_mode == C.PLACEMENT_MANUAL
    is_cyl = connector_type == C.CONNECTOR_CYL
    is_rect = connector_type == C.CONNECTOR_RECT
    inputs.itemById(INP_PIN_D).isVisible = is_cyl
    inputs.itemById(INP_PIN_DEPTH).isVisible = is_cyl
    inputs.itemById(INP_CREATE_DOWELS).isVisible = is_cyl
    inputs.itemById(INP_RECT_W).isVisible = is_rect
    inputs.itemById(INP_RECT_H).isVisible = is_rect


def _update_summary(inputs):
    faces = _selected_faces(inputs)
    inputs.itemById(INP_SUMMARY).text = S.connector_summary(
        faces,
        _dropdown_name(inputs, INP_PLACEMENT),
        _dropdown_name(inputs, INP_TYPE),
        inputs.itemById(INP_CREATE_DOWELS).value,
    )


class Created(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = adsk.core.Command.cast(args.command)
            inputs = cmd.commandInputs

            face_inp = inputs.addSelectionInput(INP_FACES, 'Planar faces', 'Select one or more planar faces for layout sketches')
            face_inp.addSelectionFilter('PlanarFaces')
            face_inp.setSelectionLimits(1, 0)

            placement = inputs.addDropDownCommandInput(INP_PLACEMENT, 'Placement mode', adsk.core.DropDownStyles.TextListDropDownStyle)
            placement.listItems.add(C.PLACEMENT_AUTO, True, '')
            placement.listItems.add(C.PLACEMENT_MANUAL, False, '')

            points_inp = inputs.addSelectionInput(INP_POINTS, 'Manual points', 'Select sketch points or vertices on or near the target faces')
            points_inp.addSelectionFilter('SketchPoints')
            points_inp.addSelectionFilter('Vertices')
            points_inp.setSelectionLimits(0, 0)
            points_inp.isVisible = False

            dd_type = inputs.addDropDownCommandInput(INP_TYPE, 'Connector type', adsk.core.DropDownStyles.TextListDropDownStyle)
            dd_type.listItems.add(C.CONNECTOR_CYL, True, '')
            dd_type.listItems.add(C.CONNECTOR_RECT, False, '')

            inputs.addIntegerSpinnerCommandInput(INP_COUNT, 'Connector count per face', 1, 20, 1, C.DEFAULTS['count'])
            inputs.addValueInput(INP_MARGIN, 'Edge margin', 'mm', F.value_input_mm(C.DEFAULTS['edge_margin_mm']))
            inputs.addValueInput(INP_PIN_D, 'Nominal dowel diameter', 'mm', F.value_input_mm(C.DEFAULTS['pin_diameter_mm']))
            inputs.addValueInput(INP_PIN_DEPTH, 'Dowel length', 'mm', F.value_input_mm(C.DEFAULTS['pin_depth_mm']))
            inputs.addBoolValueInput(INP_CREATE_DOWELS, 'Create standalone dowel bodies', True, '', True)
            inputs.addValueInput(INP_RECT_W, 'Rectangular key width', 'mm', F.value_input_mm(C.DEFAULTS['rect_width_mm']))
            inputs.addValueInput(INP_RECT_H, 'Rectangular key height', 'mm', F.value_input_mm(C.DEFAULTS['rect_height_mm']))
            inputs.addTextBoxCommandInput(INP_SUMMARY, 'Summary', 'Select one or more planar faces.', 7, True)

            _update_visibility(inputs)
            _update_summary(inputs)

            for handler_cls, event in [
                (InputChanged, cmd.inputChanged),
                (Validate, cmd.validateInputs),
                (Execute, cmd.execute),
                (Destroy, cmd.destroy),
            ]:
                handler = handler_cls()
                event.add(handler)
                _handlers.append(handler)
        except:
            if _ui:
                _ui.messageBox('Connector Layout Sketch command creation failed:\n{}'.format(traceback.format_exc()))


class InputChanged(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.InputChangedEventArgs.cast(args).inputs
            _update_visibility(inputs)
            _update_summary(inputs)
        except:
            F.log(traceback.format_exc())


class Validate(adsk.core.ValidateInputsEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.ValidateInputsEventArgs.cast(args).inputs
            faces = _selected_faces(inputs)
            if not faces:
                args.areInputsValid = False
                return
            if _dropdown_name(inputs, INP_PLACEMENT) == C.PLACEMENT_MANUAL:
                args.areInputsValid = inputs.itemById(INP_POINTS).selectionCount >= 1
            else:
                args.areInputsValid = True
        except:
            F.log(traceback.format_exc())


class Execute(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.CommandEventArgs.cast(args).command.commandInputs
            faces = _selected_faces(inputs)
            if not faces:
                raise RuntimeError('Select one or more planar faces.')

            connector_type = _dropdown_name(inputs, INP_TYPE)
            sketches, point_sets, total_count = S.create_connector_layout_sketches(
                faces=faces,
                placement_mode=_dropdown_name(inputs, INP_PLACEMENT),
                manual_points=S.resolve_selected_points(inputs.itemById(INP_POINTS)),
                connector_type=connector_type,
                count=int(round(inputs.itemById(INP_COUNT).value)),
                edge_margin_mm=_mm_value(inputs, INP_MARGIN),
                pin_diameter_mm=_mm_value(inputs, INP_PIN_D),
                rect_width_mm=_mm_value(inputs, INP_RECT_W),
                rect_height_mm=_mm_value(inputs, INP_RECT_H),
            )

            dowel_count = 0
            if connector_type == C.CONNECTOR_CYL and inputs.itemById(INP_CREATE_DOWELS).value:
                dowels = S.create_dowel_bodies_from_point_sets(
                    point_sets=point_sets,
                    pin_diameter_mm=_mm_value(inputs, INP_PIN_D),
                    pin_depth_mm=_mm_value(inputs, INP_PIN_DEPTH),
                    clearance_mm=C.DEFAULTS['dowel_clearance_mm'],
                    chamfer_mm=C.DEFAULTS['dowel_chamfer_mm'],
                )
                dowel_count = len(dowels)

            message = 'Created {} sketch(es) with {} connector outline(s).'.format(len(sketches), total_count)
            if dowel_count:
                message += ' Also created {} standalone dowel bod(y/ies) off to the side at nominal diameter minus {:.1f} mm.'.format(dowel_count, C.DEFAULTS['dowel_clearance_mm'])
            _ui.messageBox(message)
        except:
            if _ui:
                _ui.messageBox('Connector Layout Sketch failed:\n{}'.format(traceback.format_exc()))


class Destroy(adsk.core.CommandEventHandler):
    def notify(self, args):
        pass


def start():
    cmd_def = _ui.commandDefinitions.itemById(C.CMD_CONNECTOR_LAYOUT_ID)
    if not cmd_def:
        cmd_def = _ui.commandDefinitions.addButtonDefinition(C.CMD_CONNECTOR_LAYOUT_ID, C.CMD_CONNECTOR_LAYOUT_NAME, C.CMD_CONNECTOR_LAYOUT_DESCRIPTION)
    created = Created()
    cmd_def.commandCreated.add(created)
    _handlers.append(created)

    panel = _ui.workspaces.itemById(C.WORKSPACE_ID).toolbarPanels.itemById(C.PANEL_ID)
    if not panel.controls.itemById(C.CMD_CONNECTOR_LAYOUT_ID):
        panel.controls.addCommand(cmd_def)


def stop():
    panel = _ui.workspaces.itemById(C.WORKSPACE_ID).toolbarPanels.itemById(C.PANEL_ID)
    control = panel.controls.itemById(C.CMD_CONNECTOR_LAYOUT_ID)
    if control:
        control.deleteMe()
    cmd_def = _ui.commandDefinitions.itemById(C.CMD_CONNECTOR_LAYOUT_ID)
    if cmd_def:
        cmd_def.deleteMe()
