# 3D Print Prep Tools

A Fusion 360 add-in that combines the stable, separate commands from the working toolset:

- Split Bodies for Printing
- Connector Layout Sketch
- Number Sketch

These are intentionally separate commands. They do not run as one all-in-one workflow.

## Commands

### Split Bodies for Printing
Split one solid body into printable sections using:
- Bambu Labs X1C preset build volume
- custom X, Y, Z build volume
- safety margin
- single-axis or multi-axis splitting
- equal sections, max-size-based sections, or manual section count
- optional visual gap between output bodies

Output bodies are renamed Part_01, Part_02, and so on.

### Connector Layout Sketch
Creates visible connector layout sketches on one or more planar faces.

Features:
- cylindrical dowel outlines
- rectangular key outlines
- automatic perimeter-aware placement
- manual placement from selected sketch points or vertices
- mirrored counterpart layout for additional selected faces
- optional standalone dowel bodies for cylindrical layouts

Notes:
- dovetail mode is intentionally removed
- this command creates sketches only on faces, plus optional standalone dowels
- it does not cut or join connector geometry into the selected bodies

### Number Sketch
Creates visible block-style segmented number sketches on one or more planar faces.

Features:
- multiple face selection
- starting number input
- one sketch per selected face
- auto-incrementing numbers

## Installation

1. Copy the `3D Print Prep Tools` folder into your Fusion add-ins directory.
   - Windows typical path:
     `C:\Users\<YourUser>\AppData\Roaming\Autodesk\Autodesk Fusion 360\API\AddIns\`
   - macOS typical path:
     `~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/`
2. Start Fusion 360.
3. Open `Utilities` -> `Scripts and Add-Ins`.
4. In the Add-Ins tab, find `3D Print Prep Tools`.
5. Click `Run`.

## Limitations

- Connector sketches are layout/debug tools, not cut/join geometry tools.
- Number sketches create visible sketch geometry only.
- No wall-thickness, hole-avoidance, or print-strength analysis is performed.
- Standalone dowel bodies are created off to the side in the root component for printing or inspection.


## Splitter printer presets

The splitter now includes presets for the current Bambu Lab lineup covered in this build, plus a few common non-Bambu machines, and still keeps a Custom option for anything else.
