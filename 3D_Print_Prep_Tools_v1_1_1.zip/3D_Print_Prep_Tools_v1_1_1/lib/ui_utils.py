import adsk.core

from . import constants as C
from . import fusion_utils as F

app = adsk.core.Application.get()
ui = app.userInterface if app else None


def get_workspace():
    workspace = ui.workspaces.itemById(C.WORKSPACE_ID)
    if not workspace:
        raise RuntimeError('Could not find Fusion workspace: {}'.format(C.WORKSPACE_ID))
    return workspace


def get_panel():
    panel = get_workspace().toolbarPanels.itemById(C.PANEL_ID)
    if not panel:
        raise RuntimeError('Could not find toolbar panel: {}'.format(C.PANEL_ID))
    return panel


def ensure_button(command_id: str, name: str, description: str):
    cmd_def = ui.commandDefinitions.itemById(command_id)
    if not cmd_def:
        cmd_def = ui.commandDefinitions.addButtonDefinition(command_id, name, description)
    return cmd_def


def add_button_to_panel(cmd_def: adsk.core.CommandDefinition):
    panel = get_panel()
    if not panel.controls.itemById(cmd_def.id):
        panel.controls.addCommand(cmd_def)


def remove_button_and_definition(command_id: str):
    panel = get_panel()
    control = panel.controls.itemById(command_id)
    if control:
        control.deleteMe()
    cmd_def = ui.commandDefinitions.itemById(command_id)
    if cmd_def:
        cmd_def.deleteMe()
