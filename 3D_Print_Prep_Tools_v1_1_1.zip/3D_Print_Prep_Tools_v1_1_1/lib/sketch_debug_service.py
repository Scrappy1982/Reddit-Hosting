
import math
import adsk.core
import adsk.fusion

from . import constants as C
from . import fusion_utils as F

SEGMENTS = {
    '0': 'abcfed',
    '1': 'bc',
    '2': 'abged',
    '3': 'abgcd',
    '4': 'fgbc',
    '5': 'afgcd',
    '6': 'afgcde',
    '7': 'abc',
    '8': 'abcdefg',
    '9': 'abcfgd'
}


def validate_planar_face(face: adsk.fusion.BRepFace):
    if not face:
        return False, 'Select one or more planar faces.'
    if not F.is_planar_face(face):
        return False, 'Selected face must be planar.'
    return True, ''


def resolve_selected_planar_face(selection_input):
    faces = resolve_selected_planar_faces(selection_input)
    return faces[0] if faces else None


def resolve_selected_planar_faces(selection_input):
    faces = []
    if not selection_input:
        return faces
    for idx in range(selection_input.selectionCount):
        face = adsk.fusion.BRepFace.cast(selection_input.selection(idx).entity)
        if face and F.is_planar_face(face):
            faces.append(face)
    return faces


def resolve_selected_points(selection_input):
    points = []
    if not selection_input:
        return points
    for idx in range(selection_input.selectionCount):
        entity = selection_input.selection(idx).entity
        sk_pt = adsk.fusion.SketchPoint.cast(entity)
        if sk_pt:
            geom = sk_pt.worldGeometry if hasattr(sk_pt, 'worldGeometry') else sk_pt.geometry
            if geom:
                points.append(adsk.core.Point3D.create(geom.x, geom.y, geom.z))
                continue
        vtx = adsk.fusion.BRepVertex.cast(entity)
        if vtx and vtx.geometry:
            g = vtx.geometry
            points.append(adsk.core.Point3D.create(g.x, g.y, g.z))
    return points


def create_face_debug_sketch(face: adsk.fusion.BRepFace, name: str) -> adsk.fusion.Sketch:
    sketch = F.face_sketch(face)
    sketch.name = name
    return sketch


def project_face_edges(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace):
    for i in range(face.edges.count):
        try:
            sketch.project(face.edges.item(i))
        except:
            pass




def _face_plane(face: adsk.fusion.BRepFace):
    return adsk.core.Plane.cast(face.geometry)


def _point_projected_to_face_plane(model_point: adsk.core.Point3D, face: adsk.fusion.BRepFace):
    plane = _face_plane(face)
    if not plane:
        return None
    origin = plane.origin
    normal = plane.normal.copy()
    denom = normal.dotProduct(normal)
    if abs(denom) < 1e-9:
        return None
    offset = adsk.core.Vector3D.create(origin.x - model_point.x, origin.y - model_point.y, origin.z - model_point.z)
    dist = normal.dotProduct(offset) / denom
    return adsk.core.Point3D.create(
        model_point.x + normal.x * dist,
        model_point.y + normal.y * dist,
        model_point.z + normal.z * dist,
    )


def _project_points_to_face_sketch(points_xy, source_sketch: adsk.fusion.Sketch, target_face: adsk.fusion.BRepFace, span_x_mm: float, span_y_mm: float, edge_margin_mm: float):
    target_sketch = create_face_debug_sketch(target_face, 'ConnectorLayout_{}'.format(target_face.body.name))
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), F.mm_to_cm(edge_margin_mm) * 0.15)
    placed = []
    for x, y in points_xy:
        source_model = source_sketch.sketchToModelSpace(adsk.core.Point3D.create(x, y, 0))
        target_model = _point_projected_to_face_plane(source_model, target_face)
        if not target_model:
            continue
        target_sk = target_sketch.modelToSketchSpace(target_model)
        if _candidate_fits_face(target_sketch, target_face, target_sk.x, target_sk.y, half_x, half_y, extra_margin_cm):
            placed.append((target_sk.x, target_sk.y))
    return target_sketch, placed

def face_local_bounds_from_projection(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace):
    project_face_edges(sketch, face)
    bbox = sketch.boundingBox
    return bbox.minPoint.x, bbox.maxPoint.x, bbox.minPoint.y, bbox.maxPoint.y


def _face_contains_model_point(face: adsk.fusion.BRepFace, model_point: adsk.core.Point3D) -> bool:
    evaluator = face.evaluator
    if not evaluator:
        return False
    try:
        ok, param = evaluator.getParameterAtPoint(model_point)
        if not ok:
            return False
        return evaluator.isParameterOnFace(param)
    except:
        return False


def _sample_offsets_cm(half_x_cm: float, half_y_cm: float):
    return [
        (0.0, 0.0),
        (-half_x_cm, 0.0),
        (half_x_cm, 0.0),
        (0.0, -half_y_cm),
        (0.0, half_y_cm),
        (-half_x_cm, -half_y_cm),
        (half_x_cm, -half_y_cm),
        (half_x_cm, half_y_cm),
        (-half_x_cm, half_y_cm),
    ]


def _candidate_fits_face(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace, x: float, y: float, half_x_cm: float, half_y_cm: float, extra_margin_cm: float) -> bool:
    test_half_x = half_x_cm + extra_margin_cm
    test_half_y = half_y_cm + extra_margin_cm
    for dx, dy in _sample_offsets_cm(test_half_x, test_half_y):
        model_point = sketch.sketchToModelSpace(adsk.core.Point3D.create(x + dx, y + dy, 0))
        if not _face_contains_model_point(face, model_point):
            return False
    return True


def _distance_sq(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    return dx * dx + dy * dy


def _dedupe_points(points_xy, min_sep_cm):
    if not points_xy:
        return []
    unique = []
    min_sep_sq = min_sep_cm * min_sep_cm
    for pt in points_xy:
        if all(_distance_sq(pt, other) > min_sep_sq for other in unique):
            unique.append(pt)
    return unique


def _spiral_fit_search(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm, search_radius_cm, step_cm):
    if _candidate_fits_face(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm):
        return center_x, center_y
    max_r = max(search_radius_cm, step_cm)
    rings = max(8, int(math.ceil(max_r / max(step_cm, 1e-6))))
    angle_steps = 24
    for ring in range(1, rings + 1):
        r = max_r * (ring / rings)
        for i in range(angle_steps):
            ang = (2.0 * math.pi * i) / angle_steps
            x = center_x + math.cos(ang) * r
            y = center_y + math.sin(ang) * r
            if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
                return x, y
    return None


def _search_outward_along_ray(sketch, face, center_x, center_y, angle_rad, max_radius_cm, half_x, half_y, extra_margin_cm):
    if max_radius_cm <= 0:
        return None
    low = 0.0
    high = max_radius_cm
    found = None
    for _ in range(24):
        mid = (low + high) * 0.5
        x = center_x + math.cos(angle_rad) * mid
        y = center_y + math.sin(angle_rad) * mid
        if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
            found = (x, y)
            low = mid
        else:
            high = mid
    return found


def _radial_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm):
    x0, x1, y0, y1 = face_local_bounds_from_projection(sketch, face)
    edge_margin_cm = F.mm_to_cm(edge_margin_mm)
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), edge_margin_cm * 0.15)

    usable_w = (x1 - x0) - 2.0 * (edge_margin_cm + half_x)
    usable_h = (y1 - y0) - 2.0 * (edge_margin_cm + half_y)
    if usable_w <= 0 or usable_h <= 0:
        raise RuntimeError('Not enough usable area on the selected face. Reduce edge margin, connector size, or count.')

    inside_model = face.pointOnFace
    inside_sketch = sketch.modelToSketchSpace(inside_model)
    center = _spiral_fit_search(
        sketch,
        face,
        inside_sketch.x,
        inside_sketch.y,
        half_x,
        half_y,
        extra_margin_cm,
        search_radius_cm=max(usable_w, usable_h) * 0.25,
        step_cm=min(max(usable_w, usable_h) * 0.05, F.mm_to_cm(2.0)),
    )
    if not center:
        raise RuntimeError('Could not find a valid connector centre inside the selected face.')
    center_x, center_y = center

    if count <= 1:
        return [(center_x, center_y)]

    bbox_radius = 0.5 * math.sqrt((x1 - x0) ** 2 + (y1 - y0) ** 2)
    max_radius = max(F.mm_to_cm(1.0), bbox_radius)

    # Require a real no-overlap spacing based on the connector profile size.
    profile_diag_cm = math.sqrt((2.0 * half_x) ** 2 + (2.0 * half_y) ** 2)
    min_sep_cm = max(profile_diag_cm * 1.10, F.mm_to_cm(max(span_x_mm, span_y_mm) + 0.75))
    min_sep_sq = min_sep_cm * min_sep_cm

    candidates = []

    def add_candidate(pt):
        if not pt:
            return
        if all(_distance_sq(pt, other) > (F.mm_to_cm(0.4) ** 2) for other in candidates):
            candidates.append(pt)

    # Build a broad candidate pool, biased toward the usable perimeter.
    outer_rings = [1.00, 0.92, 0.84, 0.76, 0.68, 0.58, 0.48, 0.36]
    for ring_index, factor in enumerate(outer_rings):
        ring_radius = max(F.mm_to_cm(1.0), max_radius * factor)
        angle_count = max(count * 8, 48 + ring_index * 8)
        angle_offset = (math.pi / angle_count) if (ring_index % 2) else 0.0
        for i in range(angle_count):
            angle = ((2.0 * math.pi * i) / angle_count) + angle_offset
            add_candidate(_search_outward_along_ray(sketch, face, center_x, center_y, angle, ring_radius, half_x, half_y, extra_margin_cm))

    # If the face is roomy, include the center as a last-resort candidate.
    if _candidate_fits_face(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm):
        add_candidate((center_x, center_y))

    if not candidates:
        raise RuntimeError('Could not place connectors fully inside the selected face. Try manual points, fewer connectors, or a larger face.')

    # Prefer candidates that are farther from the center first, then greedily keep
    # the points that maximize spacing across the face.
    candidates.sort(key=lambda p: _distance_sq(p, (center_x, center_y)), reverse=True)
    selected = [candidates[0]]

    while len(selected) < count:
        best_pt = None
        best_score = -1.0
        for pt in candidates:
            if any(_distance_sq(pt, other) < min_sep_sq for other in selected):
                continue
            nearest_sq = min(_distance_sq(pt, other) for other in selected)
            center_bias = 0.05 * _distance_sq(pt, (center_x, center_y))
            score = nearest_sq + center_bias
            if score > best_score:
                best_score = score
                best_pt = pt
        if best_pt is None:
            break
        selected.append(best_pt)

    if len(selected) < count:
        raise RuntimeError(
            'Only {} of {} connectors could be spread safely across the selected face without overlap. '
            'Try fewer connectors, a smaller connector size, or a smaller edge margin.'.format(len(selected), count)
        )

    return selected[:count]

def auto_layout_points(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace, count: int, edge_margin_mm: float, span_x_mm: float, span_y_mm: float):
    return _radial_layout_points(sketch, face, max(1, int(count)), edge_margin_mm, span_x_mm, span_y_mm)


def manual_layout_points(sketch: adsk.fusion.Sketch, model_points):
    pts = []
    for pt in model_points:
        sk = sketch.modelToSketchSpace(pt)
        pts.append((sk.x, sk.y))
    return pts


def add_crosshair(sketch: adsk.fusion.Sketch, x: float, y: float, half_size_cm: float):
    lines = sketch.sketchCurves.sketchLines
    lines.addByTwoPoints(adsk.core.Point3D.create(x - half_size_cm, y, 0), adsk.core.Point3D.create(x + half_size_cm, y, 0))
    lines.addByTwoPoints(adsk.core.Point3D.create(x, y - half_size_cm, 0), adsk.core.Point3D.create(x, y + half_size_cm, 0))


def add_circle_outlines(sketch: adsk.fusion.Sketch, points_xy, diameter_mm: float, crosshair_mm: float):
    circles = sketch.sketchCurves.sketchCircles
    radius_cm = F.mm_to_cm(diameter_mm * 0.5)
    half_cross = F.mm_to_cm(crosshair_mm * 0.5)
    for x, y in points_xy:
        circles.addByCenterRadius(adsk.core.Point3D.create(x, y, 0), radius_cm)
        add_crosshair(sketch, x, y, half_cross)


def add_rect_outlines(sketch: adsk.fusion.Sketch, points_xy, width_mm: float, height_mm: float, crosshair_mm: float):
    lines = sketch.sketchCurves.sketchLines
    half_w = F.mm_to_cm(width_mm * 0.5)
    half_h = F.mm_to_cm(height_mm * 0.5)
    half_cross = F.mm_to_cm(crosshair_mm * 0.5)
    for x, y in points_xy:
        corner = adsk.core.Point3D.create(x + half_w, y + half_h, 0)
        lines.addCenterPointRectangle(adsk.core.Point3D.create(x, y, 0), corner)
        add_crosshair(sketch, x, y, half_cross)


def _layout_points_for_face(face: adsk.fusion.BRepFace, placement_mode: str, manual_points, connector_type: str, count: int, edge_margin_mm: float, pin_diameter_mm: float, rect_width_mm: float, rect_height_mm: float):
    sketch = create_face_debug_sketch(face, 'ConnectorLayout_{}'.format(face.body.name))

    if connector_type == C.CONNECTOR_CYL:
        span_x_mm = pin_diameter_mm
        span_y_mm = pin_diameter_mm
    else:
        span_x_mm = rect_width_mm
        span_y_mm = rect_height_mm

    if placement_mode == C.PLACEMENT_MANUAL:
        if not manual_points:
            raise RuntimeError('Select one or more sketch points or vertices when using manual placement.')
        points_xy = manual_layout_points(sketch, manual_points)
    else:
        points_xy = auto_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)

    if connector_type == C.CONNECTOR_CYL:
        add_circle_outlines(sketch, points_xy, pin_diameter_mm, C.DEFAULTS['show_crosshair_mm'])
    else:
        add_rect_outlines(sketch, points_xy, rect_width_mm, rect_height_mm, C.DEFAULTS['show_crosshair_mm'])

    return sketch, points_xy


def create_connector_layout_sketches(faces, placement_mode: str, manual_points, connector_type: str, count: int, edge_margin_mm: float, pin_diameter_mm: float, rect_width_mm: float, rect_height_mm: float):
    if not faces:
        raise RuntimeError('Select one or more planar faces.')

    sketches = []
    total = 0
    point_sets = []

    for face in faces:
        ok, msg = validate_planar_face(face)
        if not ok:
            raise RuntimeError(msg)

    if connector_type == C.CONNECTOR_CYL:
        span_x_mm = pin_diameter_mm
        span_y_mm = pin_diameter_mm
    else:
        span_x_mm = rect_width_mm
        span_y_mm = rect_height_mm

    master_face = faces[0]
    master_sketch, master_points = _layout_points_for_face(
        master_face,
        placement_mode,
        manual_points,
        connector_type,
        count,
        edge_margin_mm,
        pin_diameter_mm,
        rect_width_mm,
        rect_height_mm,
    )
    sketches.append(master_sketch)
    point_sets.append(master_points)
    total += len(master_points)

    if placement_mode == C.PLACEMENT_AUTO and len(faces) > 1:
        for face in faces[1:]:
            sketch, points_xy = _project_points_to_face_sketch(master_points, master_sketch, face, span_x_mm, span_y_mm, edge_margin_mm)
            if len(points_xy) != len(master_points):
                # Fallback to an independent solve only if the projected counterpart does not fully fit.
                try:
                    sketch.deleteMe()
                except:
                    pass
                sketch, points_xy = _layout_points_for_face(face, placement_mode, manual_points, connector_type, count, edge_margin_mm, pin_diameter_mm, rect_width_mm, rect_height_mm)
            else:
                if connector_type == C.CONNECTOR_CYL:
                    add_circle_outlines(sketch, points_xy, pin_diameter_mm, C.DEFAULTS['show_crosshair_mm'])
                else:
                    add_rect_outlines(sketch, points_xy, rect_width_mm, rect_height_mm, C.DEFAULTS['show_crosshair_mm'])
            sketches.append(sketch)
            point_sets.append(points_xy)
            total += len(points_xy)
        return sketches, point_sets, total

    for face in faces[1:]:
        sketch, points_xy = _layout_points_for_face(face, placement_mode, manual_points, connector_type, count, edge_margin_mm, pin_diameter_mm, rect_width_mm, rect_height_mm)
        sketches.append(sketch)
        point_sets.append(points_xy)
        total += len(points_xy)
    return sketches, point_sets, total


def _scene_x_offset_cm():
    root = F.root_comp()
    max_x = 0.0
    max_y = 0.0
    for i in range(root.bRepBodies.count):
        body = root.bRepBodies.item(i)
        if not body or not body.isValid:
            continue
        box = body.boundingBox
        max_x = max(max_x, box.maxPoint.x)
        max_y = max(max_y, box.maxPoint.y)
    return max_x + F.mm_to_cm(C.DEFAULTS['dowel_staging_margin_mm'] + 20.0), max_y


def _add_edge_chamfers(body: adsk.fusion.BRepBody, chamfer_mm: float):
    if chamfer_mm <= 0:
        return

    z_min = None
    z_max = None
    circular_edges = []
    for i in range(body.edges.count):
        edge = body.edges.item(i)
        circle = adsk.core.Circle3D.cast(edge.geometry)
        if not circle:
            continue
        z_val = circle.center.z
        circular_edges.append((edge, z_val))
        z_min = z_val if z_min is None else min(z_min, z_val)
        z_max = z_val if z_max is None else max(z_max, z_val)

    if z_min is None or z_max is None:
        return

    target_edges = adsk.core.ObjectCollection.create()
    for edge, z_val in circular_edges:
        if abs(z_val - z_min) < 1e-6 or abs(z_val - z_max) < 1e-6:
            target_edges.add(edge)

    if target_edges.count == 0:
        return

    chamfers = F.root_comp().features.chamferFeatures
    inp = chamfers.createInput2()
    inp.chamferEdgeSets.addEqualDistanceChamferEdgeSet(target_edges, F.value_input_mm(chamfer_mm), True)
    chamfers.add(inp)


def create_dowel_bodies_from_point_sets(point_sets, pin_diameter_mm: float, pin_depth_mm: float, clearance_mm: float, chamfer_mm: float):
    if not point_sets:
        return []

    # Dowel bodies are standalone helpers. Create one dowel per connector position set,
    # not per face, so mirrored or repeated faces do not multiply the dowel count.
    dowel_source_points = None
    for pts in point_sets:
        if pts:
            dowel_source_points = pts
            break
    if not dowel_source_points:
        return []

    root = F.root_comp()
    profile_sketch = root.sketches.add(root.xYConstructionPlane)
    profile_sketch.name = 'DowelBodies'

    circles = profile_sketch.sketchCurves.sketchCircles
    effective_diameter_mm = max(0.1, pin_diameter_mm - clearance_mm)
    radius_cm = F.mm_to_cm(effective_diameter_mm * 0.5)
    spacing_cm = F.mm_to_cm(max(pin_diameter_mm + C.DEFAULTS['dowel_spacing_mm'], effective_diameter_mm + 1.0))
    x_start, y_base = _scene_x_offset_cm()

    x_cursor = x_start
    dowel_total = len(dowel_source_points)
    for _ in range(dowel_total):
        circles.addByCenterRadius(adsk.core.Point3D.create(x_cursor, y_base, 0), radius_cm)
        x_cursor += spacing_cm

    extrudes = root.features.extrudeFeatures
    created = []
    for idx in range(profile_sketch.profiles.count):
        profile = profile_sketch.profiles.item(idx)
        ext_input = extrudes.createInput(profile, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        dist_def = adsk.fusion.DistanceExtentDefinition.create(F.value_input_mm(pin_depth_mm))
        ext_input.setOneSideExtent(dist_def, adsk.fusion.ExtentDirections.PositiveExtentDirection)
        feat = extrudes.add(ext_input)
        if feat and feat.bodies and feat.bodies.count > 0:
            body = feat.bodies.item(0)
            if body:
                body.name = 'Dowel_{:02d}'.format(idx + 1)
                _add_edge_chamfers(body, chamfer_mm)
                created.append(body)
    return created


def _add_rect_loop(lines, x0, y0, x1, y1):
    p1 = adsk.core.Point3D.create(x0, y0, 0)
    p2 = adsk.core.Point3D.create(x1, y0, 0)
    p3 = adsk.core.Point3D.create(x1, y1, 0)
    p4 = adsk.core.Point3D.create(x0, y1, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)


def add_digit_geometry(sketch: adsk.fusion.Sketch, digit: str, center_x: float, center_y: float, size_mm: float):
    segs = SEGMENTS.get(digit, '')
    lines = sketch.sketchCurves.sketchLines
    s = F.mm_to_cm(size_mm)
    width = s * 0.56
    height = s
    thickness = F.mm_to_cm(max(1.0, size_mm * 0.14))
    gap = max(thickness * 0.45, F.mm_to_cm(0.35))
    half_w = width / 2.0
    half_h = height / 2.0
    left_x = center_x - half_w
    right_x = center_x + half_w
    top_y = center_y + half_h
    mid_y = center_y
    bot_y = center_y - half_h

    seg_boxes = {
        'a': (left_x + gap, top_y - thickness, right_x - gap, top_y),
        'b': (right_x - thickness, mid_y + gap, right_x, top_y - gap),
        'c': (right_x - thickness, bot_y + gap, right_x, mid_y - gap),
        'd': (left_x + gap, bot_y, right_x - gap, bot_y + thickness),
        'e': (left_x, bot_y + gap, left_x + thickness, mid_y - gap),
        'f': (left_x, mid_y + gap, left_x + thickness, top_y - gap),
        'g': (left_x + gap, mid_y - thickness / 2.0, right_x - gap, mid_y + thickness / 2.0),
    }

    for seg in segs:
        x0, y0, x1, y1 = seg_boxes[seg]
        if x1 > x0 and y1 > y0:
            _add_rect_loop(lines, x0, y0, x1, y1)


def create_number_sketch(face: adsk.fusion.BRepFace, number_text: str, size_mm: float):
    ok, msg = validate_planar_face(face)
    if not ok:
        raise RuntimeError(msg)
    if not number_text or not all(ch.isdigit() for ch in number_text):
        raise RuntimeError('Number text must contain digits only for this debug tool.')

    sketch = create_face_debug_sketch(face, 'NumberSketch_{}_{}'.format(face.body.name, number_text))
    center_model = face.pointOnFace
    center_sketch = sketch.modelToSketchSpace(center_model)

    spacing = F.mm_to_cm(size_mm * C.DEFAULTS['number_spacing_factor'])
    start_x = center_sketch.x - spacing * (len(number_text) - 1) / 2.0

    for idx, digit in enumerate(number_text):
        add_digit_geometry(sketch, digit, start_x + idx * spacing, center_sketch.y, size_mm)

    return sketch


def create_number_sketches(faces, starting_number: int, size_mm: float):
    sketches = []
    current = starting_number
    for face in faces:
        ok, msg = validate_planar_face(face)
        if not ok:
            raise RuntimeError(msg)
        sketches.append(create_number_sketch(face, str(current), size_mm))
        current += 1
    return sketches


def connector_summary(faces, placement_mode, connector_type, create_dowels):
    if not faces:
        return 'Select one or more planar faces. The command will create visible sketches only, with optional standalone dowel bodies for cylindrical layouts.'
    return (
        'Faces selected: {}\n'
        'Placement mode: {}\n'
        'Connector type: {}\n'
        'Create dowel bodies: {}\n'
        'Output: one sketch per face{}'
    ).format(
        len(faces),
        placement_mode,
        connector_type,
        'Yes' if create_dowels else 'No',
        ' plus standalone dowel bodies' if create_dowels and connector_type == C.CONNECTOR_CYL else '',
    )


def number_summary(faces, starting_number):
    if not faces:
        return 'Select one or more planar faces. The command will create visible numbered sketches only. No engraving or embossing is done.'
    end_number = starting_number + len(faces) - 1
    return 'Faces selected: {}\nNumbers: {} to {}\nOutput: one visible sketch per face'.format(len(faces), starting_number, end_number)
