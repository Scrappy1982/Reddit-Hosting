import math
import adsk.core
import adsk.fusion

from . import constants as C
from . import fusion_utils as F


def effective_build_volume_mm(preset_name: str, custom_xyz_mm, safety_margin_mm: float):
    if preset_name == 'Custom':
        x_mm, y_mm, z_mm = custom_xyz_mm
    else:
        preset = C.PRINTER_PRESETS_MM.get(preset_name)
        if not preset:
            raise RuntimeError('Unknown printer preset: {}'.format(preset_name))
        x_mm, y_mm, z_mm = preset
    return (
        max(1.0, x_mm - (2.0 * safety_margin_mm)),
        max(1.0, y_mm - (2.0 * safety_margin_mm)),
        max(1.0, z_mm - (2.0 * safety_margin_mm)),
    )


def build_limit_for_axis_mm(axis_name: str, effective_xyz_mm):
    axis = axis_name.upper()
    if axis == 'X':
        return effective_xyz_mm[0]
    if axis == 'Y':
        return effective_xyz_mm[1]
    return effective_xyz_mm[2]


def axis_length_mm(body: adsk.fusion.BRepBody, axis_name: str) -> float:
    axis_index, _ = F.axis_info(axis_name)
    mn, mx = F.bbox_axis_min_max(body.boundingBox, axis_index)
    return F.cm_to_mm(mx - mn)


def compute_section_count_for_body(body: adsk.fusion.BRepBody, axis_name: str, strategy: str, effective_xyz_mm, manual_count: int):
    axis_len_mm = axis_length_mm(body, axis_name)
    axis_limit_mm = build_limit_for_axis_mm(axis_name, effective_xyz_mm)
    if strategy == 'Manual section count':
        return max(1, int(manual_count))
    count = int(math.ceil(axis_len_mm / axis_limit_mm)) if axis_limit_mm > 0 else 1
    return max(1, count)


def compute_equal_positions_cm(body: adsk.fusion.BRepBody, axis_name: str, section_count: int):
    if section_count <= 1:
        return []
    axis_index, _ = F.axis_info(axis_name)
    axis_min, axis_max = F.bbox_axis_min_max(body.boundingBox, axis_index)
    total = axis_max - axis_min
    step = total / float(section_count)
    return [axis_min + (step * idx) for idx in range(1, section_count)]


def body_spans_plane(body: adsk.fusion.BRepBody, axis_name: str, plane_pos_cm: float) -> bool:
    axis_index, _ = F.axis_info(axis_name)
    axis_min, axis_max = F.bbox_axis_min_max(body.boundingBox, axis_index)
    tol_cm = 1e-6
    return (axis_min + tol_cm) < plane_pos_cm < (axis_max - tol_cm)


def split_once(body: adsk.fusion.BRepBody, axis_name: str, plane_pos_cm: float):
    root = F.get_root_component()
    plane = F.create_offset_plane(axis_name, plane_pos_cm)
    split_features = root.features.splitBodyFeatures
    split_input = split_features.createInput(body, plane, True)
    feature = split_features.add(split_input)
    result_bodies = []
    for idx in range(feature.bodies.count):
        split_body = feature.bodies.item(idx)
        if split_body and split_body.isValid:
            result_bodies.append(split_body)
    if len(result_bodies) < 2:
        raise RuntimeError('Split feature completed but did not create multiple bodies.')
    return result_bodies, plane


def split_body_single_axis(body: adsk.fusion.BRepBody, axis_name: str, section_count: int):
    if section_count <= 1:
        return [body], []

    working_bodies = [body]
    created_planes = []
    split_positions = compute_equal_positions_cm(body, axis_name, section_count)

    for plane_pos_cm in split_positions:
        target_body = None
        for candidate in working_bodies:
            if candidate and candidate.isValid and body_spans_plane(candidate, axis_name, plane_pos_cm):
                target_body = candidate
                break
        if not target_body:
            raise RuntimeError('Could not find a valid target body for one of the split planes.')

        new_bodies, plane = split_once(target_body, axis_name, plane_pos_cm)
        created_planes.append(plane)
        surviving = [b for b in working_bodies if b != target_body and b and b.isValid]
        surviving.extend(new_bodies)
        working_bodies = F.sort_bodies_along_axis(surviving, axis_name)

    F.rename_bodies_sequential(working_bodies, 'Part')
    return working_bodies, created_planes


def split_body_multi_axis(body: adsk.fusion.BRepBody, axis_order, effective_xyz_mm):
    working = [body]
    created_planes = []

    for axis_name in axis_order:
        next_bodies = []
        for candidate in working:
            section_count = compute_section_count_for_body(candidate, axis_name, 'Max-size-based sections', effective_xyz_mm, 1)
            new_bodies, new_planes = split_body_single_axis(candidate, axis_name, section_count)
            next_bodies.extend(new_bodies)
            created_planes.extend(new_planes)
        working = next_bodies

    if axis_order:
        working = F.sort_bodies_along_axis(working, axis_order[0])
    F.rename_bodies_sequential(working, 'Part')
    return working, created_planes


def split_summary(body: adsk.fusion.BRepBody, effective_xyz_mm):
    lx, ly, lz = F.bbox_lengths_cm(body.boundingBox)
    return '\n'.join([
        f'Body size: X {F.cm_to_mm(lx):.2f} mm, Y {F.cm_to_mm(ly):.2f} mm, Z {F.cm_to_mm(lz):.2f} mm',
        f'Effective build: X {effective_xyz_mm[0]:.2f} mm, Y {effective_xyz_mm[1]:.2f} mm, Z {effective_xyz_mm[2]:.2f} mm',
    ])
