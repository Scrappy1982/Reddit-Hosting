import adsk.core
import traceback

from .commands import split_command
from .commands import connector_layout_command
from .commands import number_sketch_command

_app = adsk.core.Application.get()
_ui = _app.userInterface if _app else None


def run(context):
    try:
        split_command.start()
        connector_layout_command.start()
        number_sketch_command.start()
    except:
        if _ui:
            _ui.messageBox('3D Print Prep Tools start failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        number_sketch_command.stop()
        connector_layout_command.stop()
        split_command.stop()
    except:
        if _ui:
            _ui.messageBox('3D Print Prep Tools stop failed:\n{}'.format(traceback.format_exc()))
