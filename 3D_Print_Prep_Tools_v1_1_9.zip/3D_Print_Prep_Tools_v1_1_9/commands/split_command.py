import traceback
import adsk.core
import adsk.fusion

from ..lib import constants as C
from ..lib import fusion_utils as F
from ..lib import split_service as S
from ..lib import ui_utils as UI

app = adsk.core.Application.get()
ui = app.userInterface if app else None

INP_BODY = 'splitBody'
INP_PRESET = 'splitPreset'
INP_CUSTOM_X = 'splitCustomX'
INP_CUSTOM_Y = 'splitCustomY'
INP_CUSTOM_Z = 'splitCustomZ'
INP_MARGIN = 'splitMargin'
INP_MULTI = 'splitMultiAxis'
INP_AXIS = 'splitAxis'
INP_STRATEGY = 'splitStrategy'
INP_MANUAL = 'splitManualCount'
INP_AXIS_ORDER = 'splitAxisOrder'
INP_GAP = 'splitAddGap'
INP_GAP_SIZE = 'splitGapSize'
INP_SUMMARY = 'splitSummary'


class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = adsk.core.Command.cast(args.command)
            inputs = cmd.commandInputs

            body_sel = inputs.addSelectionInput(INP_BODY, 'Body to split', 'Select exactly one solid body.')
            body_sel.addSelectionFilter('Bodies')
            body_sel.setSelectionLimits(1, 1)

            preset = inputs.addDropDownCommandInput(INP_PRESET, 'Printer preset', adsk.core.DropDownStyles.TextListDropDownStyle)
            for idx, preset_name in enumerate(C.PRINTER_PRESETS_MM.keys()):
                preset.listItems.add(preset_name, preset_name == C.DEFAULTS['default_preset'], '')

            inputs.addValueInput(INP_CUSTOM_X, 'Custom max X', 'mm', F.value_input_mm(C.DEFAULTS['build_x_mm']))
            inputs.addValueInput(INP_CUSTOM_Y, 'Custom max Y', 'mm', F.value_input_mm(C.DEFAULTS['build_y_mm']))
            inputs.addValueInput(INP_CUSTOM_Z, 'Custom max Z', 'mm', F.value_input_mm(C.DEFAULTS['build_z_mm']))
            inputs.addValueInput(INP_MARGIN, 'Safety margin', 'mm', F.value_input_mm(C.DEFAULTS['safety_margin_mm']))

            axis = inputs.addDropDownCommandInput(INP_AXIS, 'Split axis', adsk.core.DropDownStyles.TextListDropDownStyle)
            for idx, axis_name in enumerate(C.AXES):
                axis.listItems.add(axis_name, idx == 0, '')

            strategy = inputs.addDropDownCommandInput(INP_STRATEGY, 'Split strategy', adsk.core.DropDownStyles.TextListDropDownStyle)
            for idx, name in enumerate(C.STRATEGIES):
                strategy.listItems.add(name, name == 'Max-size-based sections', '')

            inputs.addIntegerSpinnerCommandInput(INP_MANUAL, 'Manual section count', 1, 999, 1, C.DEFAULTS['manual_sections'])
            inputs.addBoolValueInput(INP_MULTI, 'Enable multi-axis splitting', True, '', False)
            inputs.addStringValueInput(INP_AXIS_ORDER, 'Axis order', 'X,Y,Z')
            inputs.addBoolValueInput(INP_GAP, 'Add visual gap between bodies', True, '', False)
            inputs.addStringValueInput(INP_GAP_SIZE, 'Gap size', '{} mm'.format(C.DEFAULTS['gap_mm']))
            inputs.addTextBoxCommandInput(INP_SUMMARY, 'Summary', 'Select a body to preview the split result.', 8, True)

            _update_visibility(inputs)
            _update_summary(inputs)

            cmd.inputChanged.add(F.register_handler(InputChangedHandler()))
            cmd.validateInputs.add(F.register_handler(ValidateInputsHandler()))
            cmd.execute.add(F.register_handler(ExecuteHandler()))
            cmd.destroy.add(F.register_handler(DestroyHandler()))
        except:
            ui.messageBox('Split command creation failed:\n{}'.format(traceback.format_exc()))


class InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.InputChangedEventArgs.cast(args).inputs
            _update_visibility(inputs)
            _update_summary(inputs)
        except:
            F.log(traceback.format_exc())


class ValidateInputsHandler(adsk.core.ValidateInputsEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.ValidateInputsEventArgs.cast(args).inputs
            args.areInputsValid = _selected_body(inputs) is not None
        except:
            F.log(traceback.format_exc())


class ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            inputs = adsk.core.CommandEventArgs.cast(args).command.commandInputs
            body = _selected_body(inputs)
            if not body:
                raise RuntimeError('Select one solid body.')

            effective = _effective_volume(inputs)
            if inputs.itemById(INP_MULTI).value:
                axis_order = _parse_axis_order(inputs.itemById(INP_AXIS_ORDER).value)
                if not axis_order:
                    raise RuntimeError('Enter a valid axis order such as X,Y,Z.')
                bodies, _ = S.split_body_multi_axis(body, axis_order, effective)
                gap_axis = axis_order[0]
            else:
                axis_name = F.dropdown_name(inputs.itemById(INP_AXIS))
                strategy = F.dropdown_name(inputs.itemById(INP_STRATEGY))
                manual_count = int(inputs.itemById(INP_MANUAL).value)
                section_count = S.compute_section_count_for_body(body, axis_name, strategy, effective, manual_count)
                if section_count <= 1:
                    ui.messageBox('The selected body already fits within the requested size along {}.'.format(axis_name))
                    return
                bodies, _ = S.split_body_single_axis(body, axis_name, section_count)
                gap_axis = axis_name

            if inputs.itemById(INP_GAP).value:
                gap_mm = F.parse_length_mm(inputs.itemById(INP_GAP_SIZE).value)
                if gap_mm <= 0:
                    raise RuntimeError('Gap size must be greater than 0 mm.')
                F.apply_visual_gap_to_bodies(bodies, gap_axis, gap_mm)

            ui.messageBox('Split complete. Created {} bodies named Part_01, Part_02, and so on.'.format(len(bodies)))
        except:
            ui.messageBox('Split Bodies failed:\n{}'.format(traceback.format_exc()))


class DestroyHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        pass


def _selected_body(inputs):
    sel = inputs.itemById(INP_BODY)
    if not sel or sel.selectionCount != 1:
        return None
    body = adsk.fusion.BRepBody.cast(sel.selection(0).entity)
    return body if body and body.isSolid else None


def _effective_volume(inputs):
    preset_name = F.dropdown_name(inputs.itemById(INP_PRESET))
    custom_xyz = (
        F.value_command_input_mm(inputs.itemById(INP_CUSTOM_X)),
        F.value_command_input_mm(inputs.itemById(INP_CUSTOM_Y)),
        F.value_command_input_mm(inputs.itemById(INP_CUSTOM_Z)),
    )
    safety_margin_mm = F.value_command_input_mm(inputs.itemById(INP_MARGIN))
    return S.effective_build_volume_mm(preset_name, custom_xyz, safety_margin_mm)


def _parse_axis_order(value: str):
    parts = [part.strip().upper() for part in value.split(',') if part.strip()]
    return [p for p in parts if p in C.AXES]


def _update_visibility(inputs):
    use_custom = F.dropdown_name(inputs.itemById(INP_PRESET)) == 'Custom'
    inputs.itemById(INP_CUSTOM_X).isVisible = use_custom
    inputs.itemById(INP_CUSTOM_Y).isVisible = use_custom
    inputs.itemById(INP_CUSTOM_Z).isVisible = use_custom

    multi = inputs.itemById(INP_MULTI).value
    manual = F.dropdown_name(inputs.itemById(INP_STRATEGY)) == 'Manual section count'
    inputs.itemById(INP_AXIS).isVisible = not multi
    inputs.itemById(INP_STRATEGY).isVisible = not multi
    inputs.itemById(INP_MANUAL).isVisible = (not multi) and manual
    inputs.itemById(INP_AXIS_ORDER).isVisible = multi
    inputs.itemById(INP_GAP_SIZE).isVisible = inputs.itemById(INP_GAP).value


def _update_summary(inputs):
    body = _selected_body(inputs)
    text = 'Select a body to preview the split result.'
    if body:
        effective = _effective_volume(inputs)
        text = S.split_summary(body, effective)
    inputs.itemById(INP_SUMMARY).text = text


def start():
    cmd_def = UI.ensure_button(C.CMD_SPLIT_ID, C.CMD_SPLIT_NAME, C.CMD_SPLIT_DESCRIPTION)
    cmd_def.commandCreated.add(F.register_handler(CommandCreatedHandler()))
    UI.add_button_to_panel(cmd_def)


def stop():
    UI.remove_button_and_definition(C.CMD_SPLIT_ID)
