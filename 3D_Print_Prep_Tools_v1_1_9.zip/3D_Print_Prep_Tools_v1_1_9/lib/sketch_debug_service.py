
import math
import adsk.core
import adsk.fusion

from . import constants as C
from . import fusion_utils as F

SEGMENTS = {
    '0': 'abcfed',
    '1': 'bc',
    '2': 'abged',
    '3': 'abgcd',
    '4': 'fgbc',
    '5': 'afgcd',
    '6': 'afgcde',
    '7': 'abc',
    '8': 'abcdefg',
    '9': 'abcfgd'
}


def validate_planar_face(face: adsk.fusion.BRepFace):
    if not face:
        return False, 'Select one or more planar faces.'
    if not F.is_planar_face(face):
        return False, 'Selected face must be planar.'
    return True, ''


def resolve_selected_planar_face(selection_input):
    faces = resolve_selected_planar_faces(selection_input)
    return faces[0] if faces else None


def resolve_selected_planar_faces(selection_input):
    faces = []
    if not selection_input:
        return faces
    for idx in range(selection_input.selectionCount):
        face = adsk.fusion.BRepFace.cast(selection_input.selection(idx).entity)
        if face and F.is_planar_face(face):
            faces.append(face)
    return faces


def resolve_selected_points(selection_input):
    points = []
    if not selection_input:
        return points
    for idx in range(selection_input.selectionCount):
        entity = selection_input.selection(idx).entity
        sk_pt = adsk.fusion.SketchPoint.cast(entity)
        if sk_pt:
            geom = sk_pt.worldGeometry if hasattr(sk_pt, 'worldGeometry') else sk_pt.geometry
            if geom:
                points.append(adsk.core.Point3D.create(geom.x, geom.y, geom.z))
                continue
        vtx = adsk.fusion.BRepVertex.cast(entity)
        if vtx and vtx.geometry:
            g = vtx.geometry
            points.append(adsk.core.Point3D.create(g.x, g.y, g.z))
    return points


def create_face_debug_sketch(face: adsk.fusion.BRepFace, name: str) -> adsk.fusion.Sketch:
    sketch = F.face_sketch(face)
    sketch.name = name
    return sketch


def project_face_edges(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace):
    for i in range(face.edges.count):
        try:
            sketch.project(face.edges.item(i))
        except:
            pass




def _face_plane(face: adsk.fusion.BRepFace):
    return adsk.core.Plane.cast(face.geometry)


def _point_projected_to_face_plane(model_point: adsk.core.Point3D, face: adsk.fusion.BRepFace):
    plane = _face_plane(face)
    if not plane:
        return None
    origin = plane.origin
    normal = plane.normal.copy()
    denom = normal.dotProduct(normal)
    if abs(denom) < 1e-9:
        return None
    offset = adsk.core.Vector3D.create(origin.x - model_point.x, origin.y - model_point.y, origin.z - model_point.z)
    dist = normal.dotProduct(offset) / denom
    return adsk.core.Point3D.create(
        model_point.x + normal.x * dist,
        model_point.y + normal.y * dist,
        model_point.z + normal.z * dist,
    )


def _project_points_to_face_sketch(points_xy, source_sketch: adsk.fusion.Sketch, target_face: adsk.fusion.BRepFace, span_x_mm: float, span_y_mm: float, edge_margin_mm: float):
    target_sketch = create_face_debug_sketch(target_face, 'ConnectorLayout_{}'.format(target_face.body.name))
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), F.mm_to_cm(edge_margin_mm) * 0.15)
    placed = []
    for x, y in points_xy:
        source_model = source_sketch.sketchToModelSpace(adsk.core.Point3D.create(x, y, 0))
        target_model = _point_projected_to_face_plane(source_model, target_face)
        if not target_model:
            continue
        target_sk = target_sketch.modelToSketchSpace(target_model)
        if _candidate_fits_face(target_sketch, target_face, target_sk.x, target_sk.y, half_x, half_y, extra_margin_cm):
            placed.append((target_sk.x, target_sk.y))
    return target_sketch, placed

def face_local_bounds_from_projection(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace):
    project_face_edges(sketch, face)
    bbox = sketch.boundingBox
    return bbox.minPoint.x, bbox.maxPoint.x, bbox.minPoint.y, bbox.maxPoint.y


def _face_contains_model_point(face: adsk.fusion.BRepFace, model_point: adsk.core.Point3D) -> bool:
    evaluator = face.evaluator
    if not evaluator:
        return False
    try:
        ok, param = evaluator.getParameterAtPoint(model_point)
        if not ok:
            return False
        return evaluator.isParameterOnFace(param)
    except:
        return False


def _sample_offsets_cm(half_x_cm: float, half_y_cm: float):
    return [
        (0.0, 0.0),
        (-half_x_cm, 0.0),
        (half_x_cm, 0.0),
        (0.0, -half_y_cm),
        (0.0, half_y_cm),
        (-half_x_cm, -half_y_cm),
        (half_x_cm, -half_y_cm),
        (half_x_cm, half_y_cm),
        (-half_x_cm, half_y_cm),
    ]


def _candidate_fits_face(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace, x: float, y: float, half_x_cm: float, half_y_cm: float, extra_margin_cm: float) -> bool:
    test_half_x = half_x_cm + extra_margin_cm
    test_half_y = half_y_cm + extra_margin_cm
    for dx, dy in _sample_offsets_cm(test_half_x, test_half_y):
        model_point = sketch.sketchToModelSpace(adsk.core.Point3D.create(x + dx, y + dy, 0))
        if not _face_contains_model_point(face, model_point):
            return False
    return True


def _distance_sq(a, b):
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    return dx * dx + dy * dy


def _dedupe_points(points_xy, min_sep_cm):
    if not points_xy:
        return []
    unique = []
    min_sep_sq = min_sep_cm * min_sep_cm
    for pt in points_xy:
        if all(_distance_sq(pt, other) > min_sep_sq for other in unique):
            unique.append(pt)
    return unique


def _spiral_fit_search(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm, search_radius_cm, step_cm):
    if _candidate_fits_face(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm):
        return center_x, center_y
    max_r = max(search_radius_cm, step_cm)
    rings = max(8, int(math.ceil(max_r / max(step_cm, 1e-6))))
    angle_steps = 24
    for ring in range(1, rings + 1):
        r = max_r * (ring / rings)
        for i in range(angle_steps):
            ang = (2.0 * math.pi * i) / angle_steps
            x = center_x + math.cos(ang) * r
            y = center_y + math.sin(ang) * r
            if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
                return x, y
    return None


def _search_outward_along_ray(sketch, face, center_x, center_y, angle_rad, max_radius_cm, half_x, half_y, extra_margin_cm):
    if max_radius_cm <= 0:
        return None
    low = 0.0
    high = max_radius_cm
    found = None
    for _ in range(24):
        mid = (low + high) * 0.5
        x = center_x + math.cos(angle_rad) * mid
        y = center_y + math.sin(angle_rad) * mid
        if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
            found = (x, y)
            low = mid
        else:
            high = mid
    return found


def _coedge_sketch_points(sketch: adsk.fusion.Sketch, coedge):
    edge = coedge.edge
    start_geom = edge.startVertex.geometry if edge and edge.startVertex else None
    end_geom = edge.endVertex.geometry if edge and edge.endVertex else None
    if not start_geom or not end_geom:
        return []
    start_pt = sketch.modelToSketchSpace(start_geom)
    end_pt = sketch.modelToSketchSpace(end_geom)
    try:
        if coedge.isOpposedToEdge:
            start_pt, end_pt = end_pt, start_pt
    except:
        pass
    return [(start_pt.x, start_pt.y), (end_pt.x, end_pt.y)]



def _outer_loop_polyline(face: adsk.fusion.BRepFace, sketch: adsk.fusion.Sketch):
    outer_loop = None
    try:
        for i in range(face.loops.count):
            loop = face.loops.item(i)
            if getattr(loop, 'isOuter', False):
                outer_loop = loop
                break
    except:
        outer_loop = None
    if not outer_loop:
        return []

    points = []
    tol_sq = F.mm_to_cm(0.05) ** 2
    for i in range(outer_loop.coEdges.count):
        pair = _coedge_sketch_points(sketch, outer_loop.coEdges.item(i))
        if len(pair) != 2:
            continue
        start_pt, end_pt = pair
        if not points:
            points.append(start_pt)
        else:
            if _distance_sq(points[-1], start_pt) > tol_sq:
                points.append(start_pt)
        points.append(end_pt)

    if len(points) >= 2 and _distance_sq(points[0], points[-1]) > tol_sq:
        points.append(points[0])
    return points



def _polyline_total_length(points_xy):
    total = 0.0
    for i in range(1, len(points_xy)):
        total += math.sqrt(_distance_sq(points_xy[i], points_xy[i - 1]))
    return total


def _polyline_signed_area(points_xy):
    if len(points_xy) < 4:
        return 0.0
    area2 = 0.0
    for i in range(len(points_xy) - 1):
        x0, y0 = points_xy[i]
        x1, y1 = points_xy[i + 1]
        area2 += (x0 * y1) - (x1 * y0)
    return area2 * 0.5


def _segment_length(p0, p1):
    return math.sqrt(_distance_sq(p0, p1))


def _segment_unit_tangent(p0, p1):
    dx = p1[0] - p0[0]
    dy = p1[1] - p0[1]
    ln = math.sqrt((dx * dx) + (dy * dy))
    if ln <= 1e-9:
        return None
    return (dx / ln, dy / ln)


def _segment_inward_normal_candidates(p0, p1, polygon_ccw: bool):
    tang = _segment_unit_tangent(p0, p1)
    if not tang:
        return []
    tx, ty = tang
    primary = (-ty, tx) if polygon_ccw else (ty, -tx)
    opposite = (-primary[0], -primary[1])
    return [primary, opposite]

def _run_angle(p0, p1):
    return math.atan2(p1[1] - p0[1], p1[0] - p0[0])


def _angle_delta_abs(a, b):
    d = abs(a - b)
    while d > math.pi:
        d -= 2.0 * math.pi
    return abs(d)


def _merge_polyline_runs(points_xy, angle_tol_deg=12.0):
    if len(points_xy) < 3:
        return []
    tol = math.radians(angle_tol_deg)
    runs = []
    run_start = points_xy[0]
    prev = points_xy[0]
    curr = points_xy[1]
    run_angle = _run_angle(prev, curr)

    for i in range(2, len(points_xy)):
        nxt = points_xy[i]
        ang = _run_angle(curr, nxt)
        if _angle_delta_abs(ang, run_angle) <= tol:
            curr = nxt
            continue
        runs.append((run_start, curr))
        run_start = curr
        curr = nxt
        run_angle = ang

    runs.append((run_start, curr))
    return [r for r in runs if _segment_length(r[0], r[1]) > 1e-6]


def _run_midpoint(run):
    p0, p1 = run
    return ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5)


def _run_orientation(run):
    p0, p1 = run
    dx = abs(p1[0] - p0[0])
    dy = abs(p1[1] - p0[1])
    if dy > dx * 1.5:
        return 'vertical'
    if dx > dy * 1.5:
        return 'horizontal'
    return 'other'


def _fit_along_inward_normal(sketch, face, boundary_xy, inward_normal_xy, inset_cm, half_x, half_y, extra_margin_cm):
    bx, by = boundary_xy
    nx, ny = inward_normal_xy
    # Start at the expected inset from the edge, then walk farther inward if needed.
    for mul in [1.0, 1.2, 1.4, 1.7, 2.0, 2.4, 2.9, 3.5, 4.2]:
        x = bx + (nx * inset_cm * mul)
        y = by + (ny * inset_cm * mul)
        if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
            return (x, y)
    return None


def _best_segment_normal(sketch, face, p0, p1, polygon_ccw, inset_cm, half_x, half_y, extra_margin_cm):
    mid = ((p0[0] + p1[0]) * 0.5, (p0[1] + p1[1]) * 0.5)
    best = None
    best_score = -1.0
    for normal in _segment_inward_normal_candidates(p0, p1, polygon_ccw):
        fitted = _fit_along_inward_normal(sketch, face, mid, normal, inset_cm, half_x, half_y, extra_margin_cm)
        if not fitted:
            continue
        score = _distance_sq(fitted, mid)
        if score > best_score:
            best_score = score
            best = normal
    return best


def _allocate_counts_across_segments(segment_infos, count):
    if not segment_infos:
        return []
    if count <= 0:
        return [0] * len(segment_infos)

    lengths = [info['length'] for info in segment_infos]
    total_len = sum(lengths)
    if total_len <= 1e-9:
        alloc = [0] * len(segment_infos)
        alloc[0] = count
        return alloc

    valid_order = sorted(range(len(segment_infos)), key=lambda i: lengths[i], reverse=True)
    alloc = [0] * len(segment_infos)

    if count <= len(segment_infos):
        for idx in valid_order[:count]:
            alloc[idx] = 1
        return alloc

    # Seed one connector on each valid segment so the result wraps around the shape.
    for i in range(len(segment_infos)):
        alloc[i] = 1
    remaining = count - len(segment_infos)

    raw = [(lengths[i] / total_len) * remaining for i in range(len(segment_infos))]
    extra = [int(v) for v in raw]
    alloc = [alloc[i] + extra[i] for i in range(len(segment_infos))]
    used = sum(alloc)
    remainder = count - used
    if remainder > 0:
        frac_order = sorted(range(len(segment_infos)), key=lambda i: (raw[i] - int(raw[i]), lengths[i]), reverse=True)
        for idx in frac_order[:remainder]:
            alloc[idx] += 1
    return alloc


def _segment_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm):
    polyline = _outer_loop_polyline(face, sketch)
    if len(polyline) < 3:
        return None

    edge_margin_cm = F.mm_to_cm(edge_margin_mm)
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), edge_margin_cm * 0.15)
    inset_cm = edge_margin_cm + max(half_x, half_y) + extra_margin_cm
    min_sep_cm = max(math.sqrt((2.0 * half_x) ** 2 + (2.0 * half_y) ** 2) * 1.15, F.mm_to_cm(max(span_x_mm, span_y_mm) + 0.75))
    min_sep_sq = min_sep_cm * min_sep_cm
    min_seg_len_cm = max(inset_cm * 0.65, F.mm_to_cm(max(span_x_mm, span_y_mm) * 0.9))

    polygon_ccw = _polyline_signed_area(polyline) > 0.0
    runs = _merge_polyline_runs(polyline)
    segment_infos = []
    for p0, p1 in runs:
        seg_len = _segment_length(p0, p1)
        if seg_len < min_seg_len_cm:
            continue
        normal = _best_segment_normal(sketch, face, p0, p1, polygon_ccw, inset_cm, half_x, half_y, extra_margin_cm)
        if not normal:
            continue
        segment_infos.append({
            'p0': p0,
            'p1': p1,
            'length': seg_len,
            'normal': normal,
            'mid': _run_midpoint((p0, p1)),
            'orientation': _run_orientation((p0, p1)),
        })

    if not segment_infos:
        return None

    # Build a dense candidate pool from every usable run.
    candidates = []
    for idx, info in enumerate(segment_infos):
        p0 = info['p0']
        p1 = info['p1']
        seg_len = info['length']
        normal = info['normal']
        tx = (p1[0] - p0[0]) / seg_len
        ty = (p1[1] - p0[1]) / seg_len
        end_pad = min(seg_len * 0.18, max(inset_cm * 0.75, min_sep_cm * 0.35))
        usable = max(0.0, seg_len - (2.0 * end_pad))
        sample_count = max(3, int(math.ceil(usable / max(min_sep_cm * 0.7, F.mm_to_cm(2.5)))))
        if usable <= 1e-6:
            t_values = [seg_len * 0.5]
        else:
            t_values = [end_pad + (usable * (k / max(1, sample_count - 1))) for k in range(sample_count)]
        for dist in t_values:
            bx = p0[0] + (tx * dist)
            by = p0[1] + (ty * dist)
            fitted = _fit_along_inward_normal(sketch, face, (bx, by), normal, inset_cm, half_x, half_y, extra_margin_cm)
            if fitted:
                candidates.append({
                    'pt': fitted,
                    'seg_idx': idx,
                    'orientation': info['orientation'],
                    'length': info['length'],
                })

    if not candidates:
        return None

    # Deduplicate candidates, preserving segment identity on the first occurrence.
    unique = []
    for cand in candidates:
        pt = cand['pt']
        if all(_distance_sq(pt, other['pt']) > (min_sep_cm * 0.55) ** 2 for other in unique):
            unique.append(cand)
    candidates = unique

    # Force side coverage if vertical runs exist.
    selected = []
    used_seg_idxs = set()
    vertical = [c for c in candidates if c['orientation'] == 'vertical']
    if vertical and count >= 3:
        left = min(vertical, key=lambda c: c['pt'][0])
        right = max(vertical, key=lambda c: c['pt'][0])
        for cand in [left, right]:
            if all(_distance_sq(cand['pt'], s['pt']) >= min_sep_sq * 0.55 for s in selected):
                selected.append(cand)
                used_seg_idxs.add(cand['seg_idx'])

    # Force bottom / lowest horizontal coverage when available.
    horizontal = [c for c in candidates if c['orientation'] == 'horizontal']
    if horizontal and len(selected) < count:
        bottom = min(horizontal, key=lambda c: c['pt'][1])
        if all(_distance_sq(bottom['pt'], s['pt']) >= min_sep_sq * 0.55 for s in selected):
            selected.append(bottom)
            used_seg_idxs.add(bottom['seg_idx'])

    # Then add one candidate from every remaining segment before adding extras.
    seg_best = {}
    for cand in candidates:
        idx = cand['seg_idx']
        if idx in used_seg_idxs:
            continue
        current = seg_best.get(idx)
        score = cand['length']
        if current is None or score > current['score']:
            seg_best[idx] = {'cand': cand, 'score': score}
    for idx, item in sorted(seg_best.items(), key=lambda kv: kv[1]['cand']['length'], reverse=True):
        if len(selected) >= count:
            break
        cand = item['cand']
        if all(_distance_sq(cand['pt'], s['pt']) >= min_sep_sq * 0.55 for s in selected):
            selected.append(cand)
            used_seg_idxs.add(idx)

    # Fill the remainder by farthest-point sampling across all remaining candidates.
    while len(selected) < count:
        best = None
        best_score = -1.0
        for cand in candidates:
            if cand in selected:
                continue
            dmin = min(_distance_sq(cand['pt'], s['pt']) for s in selected) if selected else float('inf')
            if dmin < min_sep_sq * 0.55:
                continue
            seg_bonus = 0.25 if cand['seg_idx'] not in used_seg_idxs else 0.0
            score = dmin + seg_bonus
            if score > best_score:
                best_score = score
                best = cand
        if best is None:
            break
        selected.append(best)
        used_seg_idxs.add(best['seg_idx'])

    return [s['pt'] for s in selected] if len(selected) >= count else None





def _polygon_centroid(points_xy):
    if len(points_xy) < 4:
        return None
    area2 = 0.0
    cx = 0.0
    cy = 0.0
    for i in range(len(points_xy) - 1):
        x0, y0 = points_xy[i]
        x1, y1 = points_xy[i + 1]
        cross = x0 * y1 - x1 * y0
        area2 += cross
        cx += (x0 + x1) * cross
        cy += (y0 + y1) * cross
    if abs(area2) < 1e-9:
        return None
    return (cx / (3.0 * area2), cy / (3.0 * area2))


def _face_anchor_point(sketch, face, polyline, half_x, half_y, extra_margin_cm, x0, x1, y0, y1):
    candidates = []
    centroid = _polygon_centroid(polyline) if polyline else None
    if centroid:
        candidates.append(centroid)
    candidates.append(((x0 + x1) * 0.5, (y0 + y1) * 0.5))
    try:
        center_model = face.pointOnFace
        center_sketch = sketch.modelToSketchSpace(center_model)
        candidates.append((center_sketch.x, center_sketch.y))
    except:
        pass

    search_radius = max(x1 - x0, y1 - y0) * 0.35
    step_cm = min(max(search_radius * 0.08, F.mm_to_cm(1.0)), F.mm_to_cm(5.0))
    for x, y in candidates:
        found = _spiral_fit_search(sketch, face, x, y, half_x, half_y, extra_margin_cm, search_radius, step_cm)
        if found:
            return found
    return None


def _point_angle(center, pt):
    return math.atan2(pt[1] - center[1], pt[0] - center[0])


def _angular_delta(a, b):
    d = abs(a - b)
    return min(d, (2.0 * math.pi) - d)


def _select_sector_spread_candidates(candidates, center, count, min_sep_sq):
    if not candidates:
        return None
    phase_samples = max(24, count * 8)
    best = None
    best_score = -1.0
    sector_width = (2.0 * math.pi) / count
    enriched = []
    for pt in candidates:
        radius_sq = _distance_sq(pt, center)
        enriched.append((pt, _point_angle(center, pt), radius_sq))

    for phase_idx in range(phase_samples):
        phase = (2.0 * math.pi * phase_idx) / phase_samples
        picked = []
        used = set()
        for s in range(count):
            target = phase + (s * sector_width)
            sector_best_idx = None
            sector_best_score = None
            for idx, (pt, ang, radius_sq) in enumerate(enriched):
                if idx in used:
                    continue
                if any(_distance_sq(pt, other) < min_sep_sq for other in picked):
                    continue
                angle_score = _angular_delta(ang, target)
                score = angle_score - (radius_sq * 0.0005)
                if sector_best_score is None or score < sector_best_score:
                    sector_best_score = score
                    sector_best_idx = idx
            if sector_best_idx is not None:
                used.add(sector_best_idx)
                picked.append(enriched[sector_best_idx][0])

        if len(picked) < count:
            remaining = sorted(
                [item for idx, item in enumerate(enriched) if idx not in used],
                key=lambda item: item[2],
                reverse=True
            )
            for pt, ang, radius_sq in remaining:
                if any(_distance_sq(pt, other) < min_sep_sq for other in picked):
                    continue
                picked.append(pt)
                if len(picked) >= count:
                    break

        if len(picked) < count:
            continue

        min_dist_sq = _min_pairwise_distance_sq(picked)
        avg_radius_sq = sum(_distance_sq(pt, center) for pt in picked) / float(len(picked))
        angs = [_point_angle(center, pt) for pt in picked]
        ang_spread = 0.0
        for i in range(len(angs)):
            for j in range(i + 1, len(angs)):
                ang_spread += _angular_delta(angs[i], angs[j])
        score = min_dist_sq + (avg_radius_sq * 0.15) + (ang_spread * 0.01)
        if score > best_score:
            best_score = score
            best = picked
    return best

def _point_at_polyline_distance(points_xy, distance_cm):
    if len(points_xy) < 2:
        return None
    remaining = max(0.0, distance_cm)
    for i in range(1, len(points_xy)):
        p0 = points_xy[i - 1]
        p1 = points_xy[i]
        seg_len = math.sqrt(_distance_sq(p0, p1))
        if seg_len <= 1e-9:
            continue
        if remaining <= seg_len:
            t = remaining / seg_len
            return (p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t)
        remaining -= seg_len
    return points_xy[-1]



def _fit_point_from_boundary_to_center(sketch, face, boundary_xy, center_xy, half_x, half_y, extra_margin_cm):
    bx, by = boundary_xy
    cx, cy = center_xy
    if _candidate_fits_face(sketch, face, bx, by, half_x, half_y, extra_margin_cm):
        return (bx, by)

    if not _candidate_fits_face(sketch, face, cx, cy, half_x, half_y, extra_margin_cm):
        return None

    low = 0.0
    high = 1.0
    found = None
    for _ in range(28):
        mid = (low + high) * 0.5
        x = bx + (cx - bx) * mid
        y = by + (cy - by) * mid
        if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
            found = (x, y)
            high = mid
        else:
            low = mid
    return found



def _min_pairwise_distance_sq(points_xy):
    if len(points_xy) < 2:
        return float('inf')
    best = None
    for i in range(len(points_xy)):
        for j in range(i + 1, len(points_xy)):
            d2 = _distance_sq(points_xy[i], points_xy[j])
            best = d2 if best is None else min(best, d2)
    return best if best is not None else float('inf')



def _perimeter_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm):
    x0, x1, y0, y1 = face_local_bounds_from_projection(sketch, face)
    edge_margin_cm = F.mm_to_cm(edge_margin_mm)
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), edge_margin_cm * 0.15)

    usable_w = (x1 - x0) - 2.0 * (edge_margin_cm + half_x)
    usable_h = (y1 - y0) - 2.0 * (edge_margin_cm + half_y)
    if usable_w <= 0 or usable_h <= 0:
        raise RuntimeError('Not enough usable area on the selected face. Reduce edge margin, connector size, or count.')

    center_model = face.pointOnFace
    center_sketch = sketch.modelToSketchSpace(center_model)
    center = _spiral_fit_search(
        sketch,
        face,
        center_sketch.x,
        center_sketch.y,
        half_x,
        half_y,
        extra_margin_cm,
        search_radius_cm=max(usable_w, usable_h) * 0.25,
        step_cm=min(max(usable_w, usable_h) * 0.05, F.mm_to_cm(2.0)),
    )
    if not center:
        raise RuntimeError('Could not find a valid connector centre inside the selected face.')
    if count <= 1:
        return [center]

    polyline = _outer_loop_polyline(face, sketch)
    if len(polyline) < 3:
        return _radial_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)

    perimeter_cm = _polyline_total_length(polyline)
    if perimeter_cm <= 1e-6:
        return _radial_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)

    profile_diag_cm = math.sqrt((2.0 * half_x) ** 2 + (2.0 * half_y) ** 2)
    min_sep_cm = max(profile_diag_cm * 1.08, F.mm_to_cm(max(span_x_mm, span_y_mm) + 0.5))
    min_sep_sq = min_sep_cm * min_sep_cm

    phase_samples = max(16, count * 4)
    best_points = None
    best_score = -1.0

    for phase_idx in range(phase_samples):
        phase = (perimeter_cm / phase_samples) * phase_idx
        trial = []
        ok = True
        step = perimeter_cm / count
        for i in range(count):
            dist = (phase + (i * step)) % perimeter_cm
            boundary_xy = _point_at_polyline_distance(polyline, dist)
            if not boundary_xy:
                ok = False
                break
            fitted = _fit_point_from_boundary_to_center(sketch, face, boundary_xy, center, half_x, half_y, extra_margin_cm)
            if not fitted:
                ok = False
                break
            if any(_distance_sq(fitted, other) < min_sep_sq for other in trial):
                ok = False
                break
            trial.append(fitted)

        if not ok:
            continue

        min_dist_sq = _min_pairwise_distance_sq(trial)
        center_bias = sum(_distance_sq(pt, center) for pt in trial) / max(1, len(trial))
        score = min_dist_sq + (center_bias * 0.10)
        if score > best_score:
            best_score = score
            best_points = trial

    if best_points:
        return best_points

    return _radial_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)



def _radial_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm):
    x0, x1, y0, y1 = face_local_bounds_from_projection(sketch, face)
    edge_margin_cm = F.mm_to_cm(edge_margin_mm)
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), edge_margin_cm * 0.15)

    usable_w = (x1 - x0) - 2.0 * (edge_margin_cm + half_x)
    usable_h = (y1 - y0) - 2.0 * (edge_margin_cm + half_y)
    if usable_w <= 0 or usable_h <= 0:
        raise RuntimeError('Not enough usable area on the selected face. Reduce edge margin, connector size, or count.')

    inside_model = face.pointOnFace
    inside_sketch = sketch.modelToSketchSpace(inside_model)
    center = _spiral_fit_search(
        sketch,
        face,
        inside_sketch.x,
        inside_sketch.y,
        half_x,
        half_y,
        extra_margin_cm,
        search_radius_cm=max(usable_w, usable_h) * 0.25,
        step_cm=min(max(usable_w, usable_h) * 0.05, F.mm_to_cm(2.0)),
    )
    if not center:
        raise RuntimeError('Could not find a valid connector centre inside the selected face.')
    center_x, center_y = center

    if count <= 1:
        return [(center_x, center_y)]

    bbox_radius = 0.5 * math.sqrt((x1 - x0) ** 2 + (y1 - y0) ** 2)
    max_radius = max(F.mm_to_cm(1.0), bbox_radius)

    profile_diag_cm = math.sqrt((2.0 * half_x) ** 2 + (2.0 * half_y) ** 2)
    min_sep_cm = max(profile_diag_cm * 1.10, F.mm_to_cm(max(span_x_mm, span_y_mm) + 0.75))
    min_sep_sq = min_sep_cm * min_sep_cm

    candidates = []

    def add_candidate(pt):
        if not pt:
            return
        if all(_distance_sq(pt, other) > (F.mm_to_cm(0.4) ** 2) for other in candidates):
            candidates.append(pt)

    outer_rings = [1.00, 0.92, 0.84, 0.76, 0.68, 0.58, 0.48, 0.36]
    for ring_index, factor in enumerate(outer_rings):
        ring_radius = max(F.mm_to_cm(1.0), max_radius * factor)
        angle_count = max(count * 8, 48 + ring_index * 8)
        angle_offset = (math.pi / angle_count) if (ring_index % 2) else 0.0
        for i in range(angle_count):
            angle = ((2.0 * math.pi * i) / angle_count) + angle_offset
            add_candidate(_search_outward_along_ray(sketch, face, center_x, center_y, angle, ring_radius, half_x, half_y, extra_margin_cm))

    if _candidate_fits_face(sketch, face, center_x, center_y, half_x, half_y, extra_margin_cm):
        add_candidate((center_x, center_y))

    if not candidates:
        raise RuntimeError('Could not place connectors fully inside the selected face. Try manual points, fewer connectors, or a larger face.')

    candidates.sort(key=lambda p: _distance_sq(p, (center_x, center_y)), reverse=True)
    selected = [candidates[0]]

    while len(selected) < count:
        best_pt = None
        best_score = -1.0
        for pt in candidates:
            if any(_distance_sq(pt, other) < min_sep_sq for other in selected):
                continue
            nearest_sq = min(_distance_sq(pt, other) for other in selected)
            center_bias = 0.05 * _distance_sq(pt, (center_x, center_y))
            score = nearest_sq + center_bias
            if score > best_score:
                best_score = score
                best_pt = pt
        if best_pt is None:
            break
        selected.append(best_pt)

    if len(selected) < count:
        raise RuntimeError(
            'Only {} of {} connectors could be spread safely across the selected face without overlap. '
            'Try fewer connectors, a smaller connector size, or a smaller edge margin.'.format(len(selected), count)
        )

    return selected[:count]



def _grid_range(start, stop, step):
    vals = []
    if step <= 1e-9:
        return vals
    v = start
    guard = 0
    while v <= stop + 1e-9 and guard < 2000:
        vals.append(v)
        v += step
        guard += 1
    return vals


def _try_add_seed(selected, cand, min_sep_sq):
    if not cand:
        return
    if all(_distance_sq(cand, other) >= min_sep_sq * 0.55 for other in selected):
        selected.append(cand)


def _raster_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm):
    x0, x1, y0, y1 = face_local_bounds_from_projection(sketch, face)
    edge_margin_cm = F.mm_to_cm(edge_margin_mm)
    half_x = F.mm_to_cm(span_x_mm * 0.5)
    half_y = F.mm_to_cm(span_y_mm * 0.5)
    extra_margin_cm = max(F.mm_to_cm(0.25), edge_margin_cm * 0.15)

    usable_x0 = x0 + edge_margin_cm + half_x
    usable_x1 = x1 - edge_margin_cm - half_x
    usable_y0 = y0 + edge_margin_cm + half_y
    usable_y1 = y1 - edge_margin_cm - half_y
    if usable_x1 <= usable_x0 or usable_y1 <= usable_y0:
        return None

    profile_diag_cm = math.sqrt((2.0 * half_x) ** 2 + (2.0 * half_y) ** 2)
    min_sep_cm = max(profile_diag_cm * 1.10, F.mm_to_cm(max(span_x_mm, span_y_mm) + 0.75))
    min_sep_sq = min_sep_cm * min_sep_cm
    step_cm = max(F.mm_to_cm(1.5), min(half_x, half_y, F.mm_to_cm(max(span_x_mm, span_y_mm) * 0.35)))

    candidates = []
    for y in _grid_range(usable_y0, usable_y1, step_cm):
        for x in _grid_range(usable_x0, usable_x1, step_cm):
            if _candidate_fits_face(sketch, face, x, y, half_x, half_y, extra_margin_cm):
                candidates.append((x, y))

    if not candidates:
        return None

    # Seed with geometric extremes first so tall side runs do not get ignored.
    selected = []
    left = min(candidates, key=lambda p: (p[0], p[1]))
    right = max(candidates, key=lambda p: (p[0], -p[1]))
    bottom = min(candidates, key=lambda p: (p[1], p[0]))
    top = max(candidates, key=lambda p: (p[1], -p[0]))

    if count == 1:
        center = min(candidates, key=lambda p: (p[0] - ((usable_x0 + usable_x1) * 0.5)) ** 2 + (p[1] - ((usable_y0 + usable_y1) * 0.5)) ** 2)
        return [center]

    for cand in [left, right, bottom, top]:
        if len(selected) >= count:
            break
        _try_add_seed(selected, cand, min_sep_sq)

    # Add branch coverage by preferring candidates far from bbox centre in each quadrant.
    cx = (usable_x0 + usable_x1) * 0.5
    cy = (usable_y0 + usable_y1) * 0.5
    quadrants = [
        [p for p in candidates if p[0] <= cx and p[1] <= cy],
        [p for p in candidates if p[0] >= cx and p[1] <= cy],
        [p for p in candidates if p[0] <= cx and p[1] >= cy],
        [p for p in candidates if p[0] >= cx and p[1] >= cy],
    ]
    quad_best = []
    for bucket in quadrants:
        if not bucket:
            continue
        quad_best.append(max(bucket, key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2))
    for cand in quad_best:
        if len(selected) >= count:
            break
        _try_add_seed(selected, cand, min_sep_sq)

    # Fill the rest with farthest-point sampling across all valid centres.
    while len(selected) < count:
        best = None
        best_score = -1.0
        for cand in candidates:
            if any(_distance_sq(cand, s) < min_sep_sq * 0.55 for s in selected):
                continue
            dmin = min(_distance_sq(cand, s) for s in selected) if selected else float('inf')
            edge_bonus = (abs(cand[0] - cx) + abs(cand[1] - cy)) * 0.15
            score = dmin + edge_bonus
            if score > best_score:
                best_score = score
                best = cand
        if best is None:
            break
        selected.append(best)

    return selected if len(selected) >= count else None

def auto_layout_points(sketch: adsk.fusion.Sketch, face: adsk.fusion.BRepFace, count: int, edge_margin_mm: float, span_x_mm: float, span_y_mm: float):
    count = max(1, int(count))
    pts = _raster_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)
    if pts and len(pts) >= count:
        return pts[:count]
    pts = _segment_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)
    if pts and len(pts) >= count:
        return pts[:count]
    return _perimeter_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)


def manual_layout_points(sketch: adsk.fusion.Sketch, model_points):
    pts = []
    for pt in model_points:
        sk = sketch.modelToSketchSpace(pt)
        pts.append((sk.x, sk.y))
    return pts


def add_crosshair(sketch: adsk.fusion.Sketch, x: float, y: float, half_size_cm: float):
    lines = sketch.sketchCurves.sketchLines
    lines.addByTwoPoints(adsk.core.Point3D.create(x - half_size_cm, y, 0), adsk.core.Point3D.create(x + half_size_cm, y, 0))
    lines.addByTwoPoints(adsk.core.Point3D.create(x, y - half_size_cm, 0), adsk.core.Point3D.create(x, y + half_size_cm, 0))


def add_circle_outlines(sketch: adsk.fusion.Sketch, points_xy, diameter_mm: float, crosshair_mm: float):
    circles = sketch.sketchCurves.sketchCircles
    radius_cm = F.mm_to_cm(diameter_mm * 0.5)
    half_cross = F.mm_to_cm(crosshair_mm * 0.5)
    for x, y in points_xy:
        circles.addByCenterRadius(adsk.core.Point3D.create(x, y, 0), radius_cm)
        add_crosshair(sketch, x, y, half_cross)


def add_rect_outlines(sketch: adsk.fusion.Sketch, points_xy, width_mm: float, height_mm: float, crosshair_mm: float):
    lines = sketch.sketchCurves.sketchLines
    half_w = F.mm_to_cm(width_mm * 0.5)
    half_h = F.mm_to_cm(height_mm * 0.5)
    half_cross = F.mm_to_cm(crosshair_mm * 0.5)
    for x, y in points_xy:
        corner = adsk.core.Point3D.create(x + half_w, y + half_h, 0)
        lines.addCenterPointRectangle(adsk.core.Point3D.create(x, y, 0), corner)
        add_crosshair(sketch, x, y, half_cross)


def _layout_points_for_face(face: adsk.fusion.BRepFace, placement_mode: str, manual_points, connector_type: str, count: int, edge_margin_mm: float, pin_diameter_mm: float, rect_width_mm: float, rect_height_mm: float):
    sketch = create_face_debug_sketch(face, 'ConnectorLayout_{}'.format(face.body.name))

    if connector_type == C.CONNECTOR_CYL:
        span_x_mm = pin_diameter_mm
        span_y_mm = pin_diameter_mm
    else:
        span_x_mm = rect_width_mm
        span_y_mm = rect_height_mm

    if placement_mode == C.PLACEMENT_MANUAL:
        if not manual_points:
            raise RuntimeError('Select one or more sketch points or vertices when using manual placement.')
        points_xy = manual_layout_points(sketch, manual_points)
    else:
        points_xy = auto_layout_points(sketch, face, count, edge_margin_mm, span_x_mm, span_y_mm)

    if connector_type == C.CONNECTOR_CYL:
        add_circle_outlines(sketch, points_xy, pin_diameter_mm, C.DEFAULTS['show_crosshair_mm'])
    else:
        add_rect_outlines(sketch, points_xy, rect_width_mm, rect_height_mm, C.DEFAULTS['show_crosshair_mm'])

    return sketch, points_xy


def create_connector_layout_sketches(faces, placement_mode: str, manual_points, connector_type: str, count: int, edge_margin_mm: float, pin_diameter_mm: float, rect_width_mm: float, rect_height_mm: float):
    if not faces:
        raise RuntimeError('Select one or more planar faces.')

    sketches = []
    total = 0
    point_sets = []

    for face in faces:
        ok, msg = validate_planar_face(face)
        if not ok:
            raise RuntimeError(msg)

    if connector_type == C.CONNECTOR_CYL:
        span_x_mm = pin_diameter_mm
        span_y_mm = pin_diameter_mm
    else:
        span_x_mm = rect_width_mm
        span_y_mm = rect_height_mm

    master_face = faces[0]
    master_sketch, master_points = _layout_points_for_face(
        master_face,
        placement_mode,
        manual_points,
        connector_type,
        count,
        edge_margin_mm,
        pin_diameter_mm,
        rect_width_mm,
        rect_height_mm,
    )
    sketches.append(master_sketch)
    point_sets.append(master_points)
    total += len(master_points)

    if placement_mode == C.PLACEMENT_AUTO and len(faces) > 1:
        for face in faces[1:]:
            sketch, points_xy = _project_points_to_face_sketch(master_points, master_sketch, face, span_x_mm, span_y_mm, edge_margin_mm)
            if len(points_xy) != len(master_points):
                # Fallback to an independent solve only if the projected counterpart does not fully fit.
                try:
                    sketch.deleteMe()
                except:
                    pass
                sketch, points_xy = _layout_points_for_face(face, placement_mode, manual_points, connector_type, count, edge_margin_mm, pin_diameter_mm, rect_width_mm, rect_height_mm)
            else:
                if connector_type == C.CONNECTOR_CYL:
                    add_circle_outlines(sketch, points_xy, pin_diameter_mm, C.DEFAULTS['show_crosshair_mm'])
                else:
                    add_rect_outlines(sketch, points_xy, rect_width_mm, rect_height_mm, C.DEFAULTS['show_crosshair_mm'])
            sketches.append(sketch)
            point_sets.append(points_xy)
            total += len(points_xy)
        return sketches, point_sets, total

    for face in faces[1:]:
        sketch, points_xy = _layout_points_for_face(face, placement_mode, manual_points, connector_type, count, edge_margin_mm, pin_diameter_mm, rect_width_mm, rect_height_mm)
        sketches.append(sketch)
        point_sets.append(points_xy)
        total += len(points_xy)
    return sketches, point_sets, total


def _scene_x_offset_cm():
    root = F.root_comp()
    max_x = 0.0
    max_y = 0.0
    for i in range(root.bRepBodies.count):
        body = root.bRepBodies.item(i)
        if not body or not body.isValid:
            continue
        box = body.boundingBox
        max_x = max(max_x, box.maxPoint.x)
        max_y = max(max_y, box.maxPoint.y)
    return max_x + F.mm_to_cm(C.DEFAULTS['dowel_staging_margin_mm'] + 20.0), max_y


def _add_edge_chamfers(body: adsk.fusion.BRepBody, chamfer_mm: float):
    if chamfer_mm <= 0:
        return

    z_min = None
    z_max = None
    circular_edges = []
    for i in range(body.edges.count):
        edge = body.edges.item(i)
        circle = adsk.core.Circle3D.cast(edge.geometry)
        if not circle:
            continue
        z_val = circle.center.z
        circular_edges.append((edge, z_val))
        z_min = z_val if z_min is None else min(z_min, z_val)
        z_max = z_val if z_max is None else max(z_max, z_val)

    if z_min is None or z_max is None:
        return

    target_edges = adsk.core.ObjectCollection.create()
    for edge, z_val in circular_edges:
        if abs(z_val - z_min) < 1e-6 or abs(z_val - z_max) < 1e-6:
            target_edges.add(edge)

    if target_edges.count == 0:
        return

    chamfers = F.root_comp().features.chamferFeatures
    inp = chamfers.createInput2()
    inp.chamferEdgeSets.addEqualDistanceChamferEdgeSet(target_edges, F.value_input_mm(chamfer_mm), True)
    chamfers.add(inp)


def create_dowel_bodies_from_point_sets(point_sets, pin_diameter_mm: float, pin_depth_mm: float, clearance_mm: float, chamfer_mm: float):
    if not point_sets:
        return []

    # Dowel bodies are standalone helpers. Create one dowel per connector position set,
    # not per face, so mirrored or repeated faces do not multiply the dowel count.
    dowel_source_points = None
    for pts in point_sets:
        if pts:
            dowel_source_points = pts
            break
    if not dowel_source_points:
        return []

    root = F.root_comp()
    profile_sketch = root.sketches.add(root.xYConstructionPlane)
    profile_sketch.name = 'DowelBodies'

    circles = profile_sketch.sketchCurves.sketchCircles
    effective_diameter_mm = max(0.1, pin_diameter_mm - clearance_mm)
    radius_cm = F.mm_to_cm(effective_diameter_mm * 0.5)
    spacing_cm = F.mm_to_cm(max(pin_diameter_mm + C.DEFAULTS['dowel_spacing_mm'], effective_diameter_mm + 1.0))
    x_start, y_base = _scene_x_offset_cm()

    x_cursor = x_start
    dowel_total = len(dowel_source_points)
    for _ in range(dowel_total):
        circles.addByCenterRadius(adsk.core.Point3D.create(x_cursor, y_base, 0), radius_cm)
        x_cursor += spacing_cm

    extrudes = root.features.extrudeFeatures
    created = []
    for idx in range(profile_sketch.profiles.count):
        profile = profile_sketch.profiles.item(idx)
        ext_input = extrudes.createInput(profile, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        dist_def = adsk.fusion.DistanceExtentDefinition.create(F.value_input_mm(pin_depth_mm))
        ext_input.setOneSideExtent(dist_def, adsk.fusion.ExtentDirections.PositiveExtentDirection)
        feat = extrudes.add(ext_input)
        if feat and feat.bodies and feat.bodies.count > 0:
            body = feat.bodies.item(0)
            if body:
                body.name = 'Dowel_{:02d}'.format(idx + 1)
                _add_edge_chamfers(body, chamfer_mm)
                created.append(body)
    return created


def _add_rect_loop(lines, x0, y0, x1, y1):
    p1 = adsk.core.Point3D.create(x0, y0, 0)
    p2 = adsk.core.Point3D.create(x1, y0, 0)
    p3 = adsk.core.Point3D.create(x1, y1, 0)
    p4 = adsk.core.Point3D.create(x0, y1, 0)
    lines.addByTwoPoints(p1, p2)
    lines.addByTwoPoints(p2, p3)
    lines.addByTwoPoints(p3, p4)
    lines.addByTwoPoints(p4, p1)


def add_digit_geometry(sketch: adsk.fusion.Sketch, digit: str, center_x: float, center_y: float, size_mm: float):
    segs = SEGMENTS.get(digit, '')
    lines = sketch.sketchCurves.sketchLines
    s = F.mm_to_cm(size_mm)
    width = s * 0.56
    height = s
    thickness = F.mm_to_cm(max(1.0, size_mm * 0.14))
    gap = max(thickness * 0.45, F.mm_to_cm(0.35))
    half_w = width / 2.0
    half_h = height / 2.0
    left_x = center_x - half_w
    right_x = center_x + half_w
    top_y = center_y + half_h
    mid_y = center_y
    bot_y = center_y - half_h

    seg_boxes = {
        'a': (left_x + gap, top_y - thickness, right_x - gap, top_y),
        'b': (right_x - thickness, mid_y + gap, right_x, top_y - gap),
        'c': (right_x - thickness, bot_y + gap, right_x, mid_y - gap),
        'd': (left_x + gap, bot_y, right_x - gap, bot_y + thickness),
        'e': (left_x, bot_y + gap, left_x + thickness, mid_y - gap),
        'f': (left_x, mid_y + gap, left_x + thickness, top_y - gap),
        'g': (left_x + gap, mid_y - thickness / 2.0, right_x - gap, mid_y + thickness / 2.0),
    }

    for seg in segs:
        x0, y0, x1, y1 = seg_boxes[seg]
        if x1 > x0 and y1 > y0:
            _add_rect_loop(lines, x0, y0, x1, y1)


def create_number_sketch(face: adsk.fusion.BRepFace, number_text: str, size_mm: float):
    ok, msg = validate_planar_face(face)
    if not ok:
        raise RuntimeError(msg)
    if not number_text or not all(ch.isdigit() for ch in number_text):
        raise RuntimeError('Number text must contain digits only for this debug tool.')

    sketch = create_face_debug_sketch(face, 'NumberSketch_{}_{}'.format(face.body.name, number_text))
    center_model = face.pointOnFace
    center_sketch = sketch.modelToSketchSpace(center_model)

    spacing = F.mm_to_cm(size_mm * C.DEFAULTS['number_spacing_factor'])
    start_x = center_sketch.x - spacing * (len(number_text) - 1) / 2.0

    for idx, digit in enumerate(number_text):
        add_digit_geometry(sketch, digit, start_x + idx * spacing, center_sketch.y, size_mm)

    return sketch


def create_number_sketches(faces, starting_number: int, size_mm: float):
    sketches = []
    current = starting_number
    for face in faces:
        ok, msg = validate_planar_face(face)
        if not ok:
            raise RuntimeError(msg)
        sketches.append(create_number_sketch(face, str(current), size_mm))
        current += 1
    return sketches


def connector_summary(faces, placement_mode, connector_type, create_dowels):
    if not faces:
        return 'Select one or more planar faces. The command will create visible sketches only, with optional standalone dowel bodies for cylindrical layouts.'
    return (
        'Faces selected: {}\n'
        'Placement mode: {}\n'
        'Connector type: {}\n'
        'Create dowel bodies: {}\n'
        'Output: one sketch per face{}'
    ).format(
        len(faces),
        placement_mode,
        connector_type,
        'Yes' if create_dowels else 'No',
        ' plus standalone dowel bodies' if create_dowels and connector_type == C.CONNECTOR_CYL else '',
    )


def number_summary(faces, starting_number):
    if not faces:
        return 'Select one or more planar faces. The command will create visible numbered sketches only. No engraving or embossing is done.'
    end_number = starting_number + len(faces) - 1
    return 'Faces selected: {}\nNumbers: {} to {}\nOutput: one visible sketch per face'.format(len(faces), starting_number, end_number)
