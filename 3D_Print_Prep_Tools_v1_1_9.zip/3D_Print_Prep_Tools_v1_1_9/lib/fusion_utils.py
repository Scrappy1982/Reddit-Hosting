import traceback
import re
import adsk.core
import adsk.fusion

from . import constants as C

_app = adsk.core.Application.get()
_handlers = []


def app():
    return _app


def ui():
    return _app.userInterface if _app else None


def register_handler(handler):
    _handlers.append(handler)
    return handler


def clear_handlers():
    _handlers.clear()


def log(message: str):
    try:
        _app.log(C.LOG_PREFIX + message)
    except:
        pass


def format_trace() -> str:
    return traceback.format_exc()


def design() -> adsk.fusion.Design:
    return adsk.fusion.Design.cast(_app.activeProduct)


def get_design() -> adsk.fusion.Design:
    des = design()
    if not des:
        raise RuntimeError('The active product is not a Fusion design.')
    return des


def root_comp() -> adsk.fusion.Component:
    des = design()
    return des.rootComponent if des else None


def get_root_component() -> adsk.fusion.Component:
    root = root_comp()
    if not root:
        raise RuntimeError('Could not access the root component.')
    return root


def mm_to_cm(value_mm: float) -> float:
    return value_mm / 10.0


def cm_to_mm(value_cm: float) -> float:
    return value_cm * 10.0


def value_input_mm(value_mm: float) -> adsk.core.ValueInput:
    return adsk.core.ValueInput.createByString(f'{value_mm} mm')




def value_command_input_mm(command_input) -> float:
    """Return a ValueCommandInput in millimetres regardless of Fusion internal units."""
    if not command_input:
        return 0.0
    try:
        des = get_design()
        expr = getattr(command_input, 'expression', '')
        if des and expr:
            return des.unitsManager.evaluateExpression(expr, 'mm')
    except:
        pass
    try:
        return cm_to_mm(command_input.value)
    except:
        return 0.0



def parse_length_mm(expression: str) -> float:
    """Parse a user-entered length expression into millimetres.

    Pure numeric values are treated as millimetres on purpose so values like
    "150" do not get interpreted using document units.
    """
    if expression is None:
        raise RuntimeError('Enter a gap size such as 10 mm or 150 mm.')

    expr = str(expression).strip()
    if not expr:
        raise RuntimeError('Enter a gap size such as 10 mm or 150 mm.')

    simple = re.fullmatch(r'([+-]?\d+(?:\.\d+)?)\s*([a-zA-Z\"\']*)', expr)
    if simple:
        value = float(simple.group(1))
        unit = simple.group(2).strip().lower()
        if unit in ('', 'mm', 'millimeter', 'millimeters', 'millimetre', 'millimetres'):
            return value
        if unit in ('cm', 'centimeter', 'centimeters', 'centimetre', 'centimetres'):
            return value * 10.0
        if unit in ('m', 'meter', 'meters', 'metre', 'metres'):
            return value * 1000.0
        if unit in ('in', 'inch', 'inches', '"'):
            return value * 25.4

    des = design()
    if des:
        try:
            return des.unitsManager.evaluateExpression(expr, 'mm')
        except:
            pass

    raise RuntimeError('Invalid length value: {}. Use values like 10 mm or 150 mm.'.format(expr))

def get_dropdown_name(dropdown) -> str:
    item = dropdown.selectedItem
    return item.name if item else ''


def dropdown_name(dropdown) -> str:
    return get_dropdown_name(dropdown)


def is_planar_face(face: adsk.fusion.BRepFace) -> bool:
    if not face:
        return False
    return adsk.core.Plane.cast(face.geometry) is not None


def face_sketch(face: adsk.fusion.BRepFace) -> adsk.fusion.Sketch:
    return get_root_component().sketches.add(face)


def face_display_name(face: adsk.fusion.BRepFace) -> str:
    body_name = face.body.name if face and face.body else 'UnknownBody'
    return '{}:Face'.format(body_name)


def bbox_lengths_cm(bbox: adsk.core.BoundingBox3D):
    return (
        bbox.maxPoint.x - bbox.minPoint.x,
        bbox.maxPoint.y - bbox.minPoint.y,
        bbox.maxPoint.z - bbox.minPoint.z,
    )


def bbox_axis_min_max(bbox: adsk.core.BoundingBox3D, axis_index: int):
    mins = [bbox.minPoint.x, bbox.minPoint.y, bbox.minPoint.z]
    maxs = [bbox.maxPoint.x, bbox.maxPoint.y, bbox.maxPoint.z]
    return mins[axis_index], maxs[axis_index]


def axis_info(axis_name: str):
    root = get_root_component()
    axis = axis_name.upper()
    if axis == 'X':
        return 0, root.yZConstructionPlane
    if axis == 'Y':
        return 1, root.xZConstructionPlane
    return 2, root.xYConstructionPlane


def vector_for_axis(axis_name: str, magnitude_cm: float) -> adsk.core.Vector3D:
    axis = axis_name.upper()
    if axis == 'X':
        return adsk.core.Vector3D.create(magnitude_cm, 0, 0)
    if axis == 'Y':
        return adsk.core.Vector3D.create(0, magnitude_cm, 0)
    return adsk.core.Vector3D.create(0, 0, magnitude_cm)


def object_collection(items):
    collection = adsk.core.ObjectCollection.create()
    for item in items:
        if item:
            collection.add(item)
    return collection


def create_offset_plane(axis_name: str, offset_cm: float) -> adsk.fusion.ConstructionPlane:
    root = get_root_component()
    _, base_plane = axis_info(axis_name)
    planes = root.constructionPlanes
    plane_input = planes.createInput()
    plane_input.setByOffset(base_plane, adsk.core.ValueInput.createByReal(offset_cm))
    return planes.add(plane_input)


def sort_bodies_along_axis(bodies, axis_name: str):
    axis_index, _ = axis_info(axis_name)
    return sorted(
        [b for b in bodies if b and b.isValid],
        key=lambda body: bbox_axis_min_max(body.boundingBox, axis_index)[0]
    )


def rename_bodies_sequential(bodies, prefix='Part'):
    for index, body in enumerate(bodies, start=1):
        try:
            body.name = f'{prefix}_{index:02d}'
        except:
            pass


def apply_visual_gap_to_bodies(bodies, axis_name: str, gap_mm: float):
    if len(bodies) < 2 or gap_mm <= 0:
        return
    root = get_root_component()
    move_features = root.features.moveFeatures
    gap_cm = mm_to_cm(gap_mm)
    center_index = (len(bodies) - 1) / 2.0
    for idx, body in enumerate(bodies):
        offset_cm = (idx - center_index) * gap_cm
        if abs(offset_cm) < 1e-8:
            continue
        transform = adsk.core.Matrix3D.create()
        transform.translation = vector_for_axis(axis_name, offset_cm)
        bodies_coll = object_collection([body])
        if hasattr(move_features, 'createInput2'):
            move_input = move_features.createInput2(bodies_coll)
            move_input.defineAsFreeMove(transform)
        else:
            move_input = move_features.createInput(bodies_coll, transform)
        move_features.add(move_input)
