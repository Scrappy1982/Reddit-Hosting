WORKSPACE_ID = 'FusionSolidEnvironment'
PANEL_ID = 'SolidScriptsAddinsPanel'

ADDIN_NAME = '3D Print Prep Tools'
LOG_PREFIX = '[3D Print Prep Tools] '

CMD_SPLIT_ID = 'threeDPrintPrepToolsSplitBodiesCmd'
CMD_SPLIT_NAME = 'Split Bodies for Printing'
CMD_SPLIT_DESCRIPTION = 'Split one solid body into printable sections based on build volume.'

CMD_CONNECTOR_LAYOUT_ID = 'threeDPrintPrepToolsConnectorLayoutCmd'
CMD_CONNECTOR_LAYOUT_NAME = 'Connector Layout Sketch'
CMD_CONNECTOR_LAYOUT_DESCRIPTION = 'Create visible connector layout sketches on one or more planar faces, and optionally create printable dowel bodies.'

CMD_NUMBER_SKETCH_ID = 'threeDPrintPrepToolsNumberSketchCmd'
CMD_NUMBER_SKETCH_NAME = 'Number Sketch'
CMD_NUMBER_SKETCH_DESCRIPTION = 'Create visible geometric number sketches on one or more planar faces.'

PRINTER_PRESETS_MM = {
    'Bambu Lab X1C': (256.0, 256.0, 256.0),
    'Bambu Lab X1E': (256.0, 256.0, 256.0),
    'Bambu Lab P1P': (256.0, 256.0, 256.0),
    'Bambu Lab P1S': (256.0, 256.0, 256.0),
    'Bambu Lab P2S': (256.0, 256.0, 256.0),
    'Bambu Lab A1': (256.0, 256.0, 256.0),
    'Bambu Lab A1 mini': (180.0, 180.0, 180.0),
    'Bambu Lab H2D (single nozzle)': (325.0, 320.0, 325.0),
    'Bambu Lab H2D (dual nozzle common area)': (300.0, 320.0, 325.0),
    'Bambu Lab H2S': (340.0, 320.0, 340.0),
    'Prusa MK4S': (250.0, 210.0, 220.0),
    'Creality K1': (220.0, 220.0, 250.0),
    'Creality K1C': (220.0, 220.0, 250.0),
    'Creality K1 Max': (300.0, 300.0, 300.0),
    'Custom': None,
}

AXES = ('X', 'Y', 'Z')
STRATEGIES = (
    'Equal sections',
    'Max-size-based sections',
    'Manual section count',
)

CONNECTOR_CYL = 'Cylindrical dowels'
CONNECTOR_RECT = 'Rectangular keys'
PLACEMENT_AUTO = 'Automatic perimeter-aware'
PLACEMENT_MANUAL = 'From selected sketch points / vertices'

DEFAULTS = {
    'safety_margin_mm': 5.0,
    'build_x_mm': 256.0,
    'build_y_mm': 256.0,
    'build_z_mm': 256.0,
    'default_preset': 'Bambu Lab X1C',
    'manual_sections': 2,
    'gap_mm': 10.0,
    'count': 2,
    'edge_margin_mm': 12.0,
    'pin_diameter_mm': 6.0,
    'pin_depth_mm': 8.0,
    'dowel_clearance_mm': 0.1,
    'dowel_chamfer_mm': 0.4,
    'dowel_staging_margin_mm': 40.0,
    'dowel_spacing_mm': 3.0,
    'rect_width_mm': 8.0,
    'rect_height_mm': 4.0,
    'number_size_mm': 10.0,
    'number_spacing_factor': 0.75,
    'show_crosshair_mm': 1.5,
}
